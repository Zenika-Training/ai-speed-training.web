# Kit facultatif — L'IA au quotidien, Data Scientist

> Données fictives : aucun membre, aucun hôtel, aucun chiffre réel.

Ce kit sert aux missions **M2** (explorer), **M3** (préparer les variables) et **M4** (comparer des modèles) de
l'auto-formation. Il est **facultatif** : sans lui, chaque mission donne les sorties à relire dans ses documents.

## Ce qu'il contient

- `donnees/membres_fidelite.csv` : 3 015 lignes, une par membre du programme de fidélité (avec ses défauts) ;
- `notebooks/01-explorer.ipynb` (M2) et `notebooks/02-modeliser.ipynb` (M3, M4) : des notebooks de départ, presque
  vides. C'est toi qui demandes le code à ton assistant IA, qui l'exécutes, et qui vérifies ce qu'il affirme.

## Lancer

Il te faut `uv` (https://docs.astral.sh/uv/getting-started/installation/). Dans ce dossier :

```sh
uv sync                      # installe Python 3.12, pandas, scikit-learn, JupyterLab (une seule fois)
uv run jupyter lab notebooks
```

Tu utilises un agent de code (Claude Code, Codex, Copilot) ? Ouvre-le dans ce dossier : il peut lire les données,
écrire les cellules et les exécuter, en te demandant ton accord.
