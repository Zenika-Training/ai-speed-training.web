# Commencer ici — atelier « L'IA au quotidien — Ops »

Ce dossier contient tout ce qu'il faut pour suivre l'atelier : le cours (`modules/`) et le dépôt
d'exploitation fictif de Sillage, une API de suivi de colis (`artefacts/sillage-ops/`). Durée : environ
3 h 30. Tu peux t'arrêter à la fin d'un module et reprendre plus tard ; les modules sont indépendants.

Tu vas utiliser **deux sessions Claude Code, dans deux terminaux** :

- **SUPPORT** te guide pas à pas et ne modifie aucun fichier ;
- **TRAVAIL** est la session où tu fais les exercices, dans le projet, comme au quotidien.

L'atelier suppose que tu as déjà pris en main un agent de code (le module 1 « L'IA au quotidien du
développeur », ou un usage équivalent) : il ne réexplique ni les permissions, ni le mode plan.

## 1. Vérifie ton poste

Il te faut Claude Code avec ton accès ouvert, git, et un terminal bash ou zsh (sous Windows, Git Bash).
Rien d'autre : aucun cluster, aucun compte cloud, aucun Docker. Les manifestes se relisent, les logs et
les métriques sont des fichiers, les scripts tournent sur un dossier d'exemple.

```sh
claude --version
git --version
```

## 2. Place ce dossier hors de tout projet

Ce dossier ne doit pas se trouver dans un projet qui contient un fichier `CLAUDE.md` : Claude Code le
chargerait aussi, et le parcours se comporterait autrement.

## 3. Lance la session SUPPORT

Ouvre un premier terminal **dans ce dossier** et lance :

```sh
claude --permission-mode default
```

Puis écris :

```
Lis le fichier ATELIER-OPS.md et démarre.
```

## 4. Ouvre la session TRAVAIL quand SUPPORT te le demande

À l'étape 0.3, ouvre un second terminal **dans ce dossier** et tape :

```sh
cd artefacts/sillage-ops
git init -q && git add -A && git commit -qm "Etat initial"
claude --permission-mode default
```

## 5. Reprendre plus tard

Relance `claude --permission-mode default` dans ce dossier, puis écris :

```
Lis le fichier ATELIER-OPS.md et va au module M4.
```

## Si quelque chose coince

- Un checkpoint ne passe pas : écris `KO` dans SUPPORT ; ce n'est pas bloquant.
- SUPPORT s'écarte du parcours : écris `RECADRE`.
- Tout est cassé dans le projet : `git restore .` revient au dernier commit.

Le projet, ses logs et ses secrets sont fictifs : tu peux les donner à l'agent sans risque. Ne lance
jamais `scripts/purge-logs.sh` : le module M5 explique pourquoi.
