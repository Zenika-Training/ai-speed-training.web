# Incident en cours — lundi 24 novembre 2026, 09:12 (fictif)

Tu es d'astreinte. À 09:12, le support te transmet : « Les agences n'arrivent plus à scanner les colis depuis
un quart d'heure environ, l'écran affiche une erreur. » Tu ouvres ce dossier.

- `metriques.csv` : une ligne par minute, de 08:30 à 09:12 (route `POST /colis/scan`, pool de connexions de
  l'API, PostgreSQL).
- `logs-0830-0912.log` : les logs de l'API, du site et des batchs sur la même période.
- `deploiements.log` : les derniers changements en production.

Tu n'as que ces fichiers : on ne touche à rien en production tant que la cause n'est pas établie.
