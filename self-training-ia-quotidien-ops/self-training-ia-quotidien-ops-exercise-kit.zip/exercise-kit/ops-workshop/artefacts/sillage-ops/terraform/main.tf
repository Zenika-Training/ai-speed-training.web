# Base PostgreSQL managée de Sillage (fictive, fournisseur générique)

resource "cloud_network_security_group" "sillage_db" {
  name = "sillage-db"

  ingress {
    description = "PostgreSQL"
    port        = 5432
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
}

resource "cloud_postgresql_instance" "sillage" {
  name                    = "sillage-db"
  version                 = "16"
  size                    = "db-4cpu-16gb"
  max_connections         = 100
  security_groups         = [cloud_network_security_group.sillage_db.id]
  backup_retention_days   = 0
  deletion_protection     = false
  admin_password          = "Adm1n-Sillage-2026"
}
