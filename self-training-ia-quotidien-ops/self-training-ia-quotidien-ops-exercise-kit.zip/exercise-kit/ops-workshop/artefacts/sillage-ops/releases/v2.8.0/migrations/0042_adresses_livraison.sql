-- Migration 0042 : adresses de livraison normalisées (fictive)
-- Exécutée automatiquement au démarrage du premier pod v2.8.0.

CREATE TABLE adresses_livraison (
    id          BIGSERIAL PRIMARY KEY,
    adresse     TEXT NOT NULL,
    code_postal TEXT NOT NULL,
    ville       TEXT NOT NULL
);

INSERT INTO adresses_livraison (adresse, code_postal, ville)
SELECT DISTINCT adresse_livraison, code_postal, ville FROM colis;

ALTER TABLE colis ADD COLUMN adresse_livraison_id BIGINT REFERENCES adresses_livraison (id);

UPDATE colis c
SET adresse_livraison_id = a.id
FROM adresses_livraison a
WHERE a.adresse = c.adresse_livraison AND a.code_postal = c.code_postal AND a.ville = c.ville;

ALTER TABLE colis DROP COLUMN adresse_livraison;

CREATE INDEX idx_colis_statut ON colis (statut);
