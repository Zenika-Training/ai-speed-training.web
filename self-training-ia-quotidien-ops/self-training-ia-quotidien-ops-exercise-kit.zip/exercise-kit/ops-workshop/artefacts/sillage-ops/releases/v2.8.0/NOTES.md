# Sillage API — v2.8.0 (notes de version, fictives)

Date de déploiement souhaitée : jeudi 3 décembre 2026, 14:00.

## Nouveautés
- Les adresses de livraison sont normalisées par un service de géocodage et rangées dans une table dédiée
  `adresses_livraison` (une adresse peut servir à plusieurs colis).
- Nouvel index sur `colis.statut` pour accélérer la page « colis en attente » des agences.

## Technique
- Migration `0042_adresses_livraison.sql` (voir `migrations/`).
- Nouvelle variable d'environnement obligatoire : voir `config.diff`.
- L'API v2.8.0 lit les adresses dans `adresses_livraison` ; la v2.7.x les lit dans `colis.adresse_livraison`.
