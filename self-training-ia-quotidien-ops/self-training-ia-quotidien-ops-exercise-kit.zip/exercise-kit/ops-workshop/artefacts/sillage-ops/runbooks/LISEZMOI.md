# Runbooks (fictifs)

Une procédure par alerte qui appelle l'astreinte : quoi regarder, quoi faire, qui prévenir.
Ceux de `CertificatExpire` et `ReplicationRetard` existent dans l'outil de documentation de l'équipe ; les
autres alertes n'ont pas encore de runbook.
