#!/bin/bash
# Purge des vieux logs sur les nœuds (fictif). Lancé chaque nuit par l'astreinte :
#   ./purge-logs.sh /var/log/sillage
# Supprime tout le contenu du dossier donné, puis les archives de plus de 7 jours.

LOG_DIR=$1

cd $LOG_DIR
rm -rf *

find $LOG_DIR/archives -name "*.gz" -mtime +7 | xargs rm
echo "Purge terminée"
