# Architecture de Sillage (fictive)

- **sillage-api** : API Python, 3 pods dans Kubernetes (namespace `sillage`). Routes principales :
  `POST /colis/scan` (scan d'un colis en agence ou par un livreur, la route critique), `GET /colis/{id}`,
  `GET /colis/{id}/historique`, `POST /colis`, `GET /agences`.
  Chaque pod ouvre un pool de connexions vers PostgreSQL (`DB_POOL_SIZE`, 20 par défaut).
- **sillage-web** : le site de suivi pour les destinataires. Il appelle `GET /colis/{id}` et
  `GET /colis/{id}/historique` ; il n'appelle jamais `POST /colis/scan`.
- **PostgreSQL** : base managée (voir `terraform/`), 100 connexions au maximum.
- **Redis** : cache des lectures `GET /colis/{id}`.
- **export-transporteurs** : batch quotidien (CronJob, voir `k8s/cronjob-export-transporteurs.yaml`) qui exporte
  les colis livrés de la veille vers les transporteurs partenaires. Il ouvre 48 connexions à PostgreSQL et lit
  toute la table `colis` ; il dure environ deux heures. Il doit tourner **en dehors des heures de pointe**.
- **Supervision** : métriques par minute, règles d'alerte dans `alerting/regles.yml`, astreinte d'une personne.

Le planificateur des CronJob du cluster est réglé en **UTC** (le réglage par défaut de Kubernetes, sauf
`spec.timeZone`).
