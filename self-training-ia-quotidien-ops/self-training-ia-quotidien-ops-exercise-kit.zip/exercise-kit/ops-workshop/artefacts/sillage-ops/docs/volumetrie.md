# Volumétrie et fenêtres (fictives)

- Table `colis` : **8,4 millions de lignes**, 41 Go ; elle reçoit environ 90 écritures par seconde en journée.
- Heures de pointe des scans : **08:00 – 10:00** et **17:00 – 19:00** (heure de Paris).
- Fenêtre de déploiement : mardi et jeudi, 14:00 – 16:00, hors période de fêtes.
- Une migration qui verrouille `colis` en écriture plus de 5 secondes bloque les scans en agence.
- Sauvegarde de la base : instantané quotidien à 03:00, restauration complète en 2 h environ.
