# Plan de déploiement — <version>

## Ce qui change
## Prérequis (configuration, données, dépendances)
## Risques
| Risque | Probabilité | Impact | Comment on le détecte | Ce qu'on fait |
|---|---|---|---|---|
## Étapes (avec la commande et le contrôle de chaque étape)
## Retour arrière (jusqu'à quelle étape il est possible, et comment)
## Décision : go / no-go (qui décide, sur quels critères)
