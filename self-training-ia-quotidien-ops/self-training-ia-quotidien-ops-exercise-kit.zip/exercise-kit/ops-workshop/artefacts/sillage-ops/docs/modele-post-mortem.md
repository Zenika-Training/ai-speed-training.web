# Post-mortem — <titre de l'incident>

Statut : brouillon · Rédigé le : <date> · Sans blâme : on cherche ce qui, dans le système, a permis l'incident,
pas qui s'est trompé.

## Résumé (3 lignes)
## Impact (durée, utilisateurs touchés, requêtes en échec, SLO consommé)
## Chronologie (heure, fait observé, source)
## Causes (cause déclenchante, facteurs contributifs)
## Ce qui a bien marché
## Ce qui nous a ralentis
## Actions (action, type : prévenir / détecter / atténuer, porteur (un rôle), échéance)
