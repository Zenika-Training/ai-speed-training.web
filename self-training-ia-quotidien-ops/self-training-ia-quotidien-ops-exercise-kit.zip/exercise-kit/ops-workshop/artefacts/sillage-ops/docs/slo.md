# Objectifs de service (SLO) de Sillage (fictifs)

| Parcours | Indicateur (SLI) | Objectif (SLO) | Fenêtre |
|---|---|---|---|
| `POST /colis/scan` | part des requêtes en succès (hors 4xx) | 99,5 % | 30 jours glissants |
| `POST /colis/scan` | p95 de la durée | moins de 500 ms | 30 jours glissants |
| `GET /colis/{id}` | part des requêtes en succès | 99,0 % | 30 jours glissants |

**Budget d'erreur** de `POST /colis/scan` : 0,5 % des requêtes sur 30 jours, soit environ 3 h 36 d'indisponibilité
totale par mois.

**Qui on réveille** : l'astreinte n'est appelée la nuit (22:00 – 07:00) que si un SLO est menacé ou si une donnée
risque d'être perdue. Tout le reste devient un ticket traité en heures ouvrées.
