# sillage-ops — dépôt d'exploitation de Sillage (fictif)

> Projet d'exercice **fictif** de l'atelier « L'IA au quotidien — Ops ». Le service, l'équipe, les
> données, les adresses et les secrets sont inventés. Rien ici n'est relié à un vrai système : aucun
> cluster, aucun compte cloud. Tu peux tout donner à l'agent sans risque.

**Sillage** est l'API de suivi de colis d'un réseau d'agences de livraison. L'équipe **Balise** l'exploite :
déploiements, supervision, astreinte, scripts d'exploitation.

| Dossier | Contenu |
|---|---|
| `docs/` | architecture, SLO, volumétrie, modèles (plan de déploiement, post-mortem) |
| `releases/v2.8.0/` | la prochaine version à déployer : notes, migration de base, changement de configuration |
| `k8s/` | manifestes Kubernetes de production (API, service, ConfigMap, CronJob du batch) |
| `terraform/` | la base PostgreSQL managée et son réseau |
| `docker-compose.yml` | l'environnement de développement local |
| `.github/workflows/deploy.yml` | la CI qui déploie en production |
| `logs/` | une journée de logs de l'API (18 novembre) |
| `alerting/` | les règles d'alerte et l'historique des alertes d'octobre |
| `incident/` | ce qu'on sait de l'incident en cours le 24 novembre à 09:12 |
| `retex/` | la chronologie brute et les métriques de cet incident, pour le retour d'expérience |
| `scripts/` | les scripts d'exploitation |
| `data/exports/` | les exports quotidiens du batch `export-transporteurs` |
| `runbooks/` | les procédures d'astreinte |

Les heures sont en heure de Paris (UTC+1) sauf mention contraire.
