# Alerting (fictif)

- `regles.yml` : les 9 règles actives.
- `historique-alertes-2026-10.csv` : toutes les alertes d'octobre 2026, une ligne par déclenchement.
  `action` vaut `aucune` quand l'astreinte a acquitté sans rien faire ; sinon, ce qu'elle a fait.
- Les métriques disponibles sont celles des expressions ci-dessus, plus `sillage_db_pool_in_use` et
  `sillage_db_pool_max` (connexions du pool de chaque pod) et `http_requests_total` par `route`.
