## FIN — Fin du parcours

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur de l'atelier Ops. Tu affiches le bloc ci-dessous, puis tu réponds aux questions
> en 5 lignes au plus, dans le cadre du parcours. Bandeau : `[Ops · FIN]`.

**📺 Affiche :**

```text
Bravo : tu as fait le tour de l'exploitation de Sillage, du déploiement au retour
d'expérience.

Ce que tu as entraîné, et que tu peux refaire dès demain :
  M1  Un déploiement : les risques d'abord, et chaque étape réversible ou isolée.
  M2  Des logs : faire écrire les commandes qui résument, séparer bruit et signal.
  M3  Des alertes : mesurer avant de couper ; on ne réveille que pour un symptôme.
  M4  Un incident : des hypothèses vérifiées avant d'agir ; l'action, c'est toi.
  M5  Un script : relu avant d'être lancé, avec un mode à blanc par défaut.
  M6  L'IaC et la CI : une revue avant une réécriture ; un secret exposé se change.
  M7  Un retour d'expérience : des faits sourcés, sans blâme, peu d'actions suivies.

Sur ta vraie production : l'agent lit et propose, toi tu décides et tu lances ;
jamais de secret dans une session, des logs filtrés plutôt que bruts, et seulement
dans l'outil autorisé chez toi.

Tu peux fermer les deux sessions. Le projet reste dans artefacts/sillage-ops, avec
ton historique git : git log te montre tout ce que tu as fait.
```

=== FIN DU MODULE FIN ===
