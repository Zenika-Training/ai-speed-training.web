import java.io.BufferedReader;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

/**
 * Serveur MCP d'exercice du workshop Claude Code avancé (module B).
 *
 * Il imite une source d'incidents de production. Toutes les données sont fictives.
 * Transport stdio : un message JSON-RPC 2.0 par ligne sur l'entrée et la sortie standard.
 * Lancement : java IncidentsMcp.java   (JDK 21, aucune dépendance, rien à compiler à part)
 *
 * Outils exposés :
 *   lister_incidents  liste les incidents, filtrables par service
 *   lire_incident     donne le détail d'un incident
 */
public class IncidentsMcp {

    record Incident(String id, String service, String date, String titre, String detail) {}

    static final List<Incident> INCIDENTS = List.of(
        new Incident("INC-4127", "orders-api", "2026-10-02",
            "Commande livrée repassée en attente",
            "Le service client signale que la commande 1042, livrée le 30/09, est de nouveau au statut "
            + "PENDING. Le journal montre l'appel PATCH /orders/1042/status?status=PENDING, accepté avec "
            + "une réponse 200."),
        new Incident("INC-4133", "orders-api", "2026-10-06",
            "Montant total à zéro sur les nouvelles commandes",
            "La facturation reçoit depuis la dernière mise en production des commandes dont totalAmount "
            + "vaut 0.0. Les lignes de commande, elles, sont correctes : produits, quantités et prix "
            + "unitaires sont bien renseignés."),
        new Incident("INC-4140", "orders-api", "2026-10-09",
            "Commande acceptée avec une quantité nulle",
            "Une commande contenant la ligne {\"productId\": 2, \"quantity\": 0} a été créée avec une "
            + "réponse 201. L'équipe pensait que la contrainte @Min(1) de OrderItem l'empêchait."),
        new Incident("INC-4144", "catalogue-web", "2026-10-10",
            "Image manquante sur une fiche produit",
            "La fiche du produit Standing Desk s'affiche sans image sur le site. Le service orders-api "
            + "n'est pas concerné.")
    );

    static final String VERSION_PAR_DEFAUT = "2025-06-18";

    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        PrintStream out = new PrintStream(new FileOutputStream(FileDescriptor.out), true, StandardCharsets.UTF_8);
        String line;
        while ((line = in.readLine()) != null) {
            if (line.isBlank()) {
                continue;
            }
            Object parsed;
            try {
                parsed = new Json(line).parse();
            } catch (RuntimeException e) {
                out.println(error(null, -32700, "Parse error"));
                continue;
            }
            if (!(parsed instanceof Map<?, ?> msg)) {
                continue;
            }
            // Une notification n'a pas d'id, une réponse du client n'a pas de méthode : rien à renvoyer.
            if (!msg.containsKey("id") || !(msg.get("method") instanceof String method)) {
                continue;
            }
            out.println(handle(method, msg.get("id"), msg.get("params")));
        }
    }

    static String handle(String method, Object id, Object params) {
        Map<?, ?> p = params instanceof Map<?, ?> m ? m : Map.of();
        switch (method) {
            case "initialize": {
                Object asked = p.get("protocolVersion");
                Map<String, Object> result = new LinkedHashMap<>();
                result.put("protocolVersion", asked instanceof String v ? v : VERSION_PAR_DEFAUT);
                result.put("capabilities", Map.of("tools", Map.of()));
                result.put("serverInfo", Map.of("name", "incidents", "version", "1.0.0"));
                return result(id, result);
            }
            case "ping":
                return result(id, Map.of());
            case "tools/list":
                return result(id, Map.of("tools", tools()));
            case "tools/call": {
                Object name = p.get("name");
                Map<?, ?> a = p.get("arguments") instanceof Map<?, ?> m ? m : Map.of();
                if ("lister_incidents".equals(name)) {
                    return result(id, texte(lister(a.get("service") instanceof String s ? s : null), false));
                }
                if ("lire_incident".equals(name)) {
                    String inc = a.get("incident") instanceof String s ? s.trim() : "";
                    for (Incident i : INCIDENTS) {
                        if (i.id().equalsIgnoreCase(inc)) {
                            return result(id, texte(i.id() + " | " + i.service() + " | " + i.date() + "\n"
                                    + i.titre() + "\n\n" + i.detail(), false));
                        }
                    }
                    return result(id, texte("Incident inconnu : " + inc, true));
                }
                return result(id, texte("Outil inconnu : " + name, true));
            }
            default:
                return error(id, -32601, "Method not found: " + method);
        }
    }

    static String lister(String service) {
        StringJoiner lines = new StringJoiner("\n");
        for (Incident i : INCIDENTS) {
            if (service == null || service.isBlank() || i.service().equalsIgnoreCase(service.trim())) {
                lines.add(i.id() + " | " + i.service() + " | " + i.date() + " | " + i.titre());
            }
        }
        return lines.length() == 0 ? "Aucun incident ouvert pour ce service." : lines.toString();
    }

    static List<Object> tools() {
        Map<String, Object> lister = new LinkedHashMap<>();
        lister.put("name", "lister_incidents");
        lister.put("description", "Liste les incidents de production ouverts (identifiant, service, date, titre). "
                + "Filtre facultatif par service. Données fictives d'exercice.");
        lister.put("inputSchema", schema(Map.of("service",
                Map.of("type", "string", "description", "Nom du service, par exemple orders-api")), List.of()));

        Map<String, Object> lire = new LinkedHashMap<>();
        lire.put("name", "lire_incident");
        lire.put("description", "Donne le détail d'un incident de production à partir de son identifiant. "
                + "Données fictives d'exercice.");
        lire.put("inputSchema", schema(Map.of("incident",
                Map.of("type", "string", "description", "Identifiant de l'incident, par exemple INC-4133")),
                List.of("incident")));
        return List.of(lister, lire);
    }

    static Map<String, Object> schema(Map<String, Object> properties, List<String> required) {
        Map<String, Object> s = new LinkedHashMap<>();
        s.put("type", "object");
        s.put("properties", properties);
        if (!required.isEmpty()) {
            s.put("required", required);
        }
        s.put("additionalProperties", false);
        return s;
    }

    static Map<String, Object> texte(String text, boolean isError) {
        Map<String, Object> r = new LinkedHashMap<>();
        r.put("content", List.of(Map.of("type", "text", "text", text)));
        r.put("isError", isError);
        return r;
    }

    static String result(Object id, Object result) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("jsonrpc", "2.0");
        m.put("id", id);
        m.put("result", result);
        return toJson(m);
    }

    static String error(Object id, int code, String message) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("jsonrpc", "2.0");
        m.put("id", id);
        m.put("error", Map.of("code", code, "message", message));
        return toJson(m);
    }

    // --- JSON minimal : assez pour JSON-RPC, sans bibliothèque -----------------------------------

    static String toJson(Object o) {
        if (o == null) {
            return "null";
        }
        if (o instanceof String s) {
            return quote(s);
        }
        if (o instanceof Number || o instanceof Boolean) {
            return o.toString();
        }
        if (o instanceof Map<?, ?> m) {
            StringJoiner j = new StringJoiner(",", "{", "}");
            m.forEach((k, v) -> j.add(quote(String.valueOf(k)) + ":" + toJson(v)));
            return j.toString();
        }
        if (o instanceof List<?> l) {
            StringJoiner j = new StringJoiner(",", "[", "]");
            l.forEach(v -> j.add(toJson(v)));
            return j.toString();
        }
        throw new IllegalArgumentException("type non sérialisable : " + o.getClass());
    }

    static String quote(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                case '\n' -> b.append("\\n");
                case '\r' -> b.append("\\r");
                case '\t' -> b.append("\\t");
                default -> {
                    if (c < 0x20) {
                        b.append(String.format("\\u%04x", (int) c));
                    } else {
                        b.append(c);
                    }
                }
            }
        }
        return b.append('"').toString();
    }

    static final class Json {
        private final String s;
        private int i;

        Json(String s) {
            this.s = s;
        }

        Object parse() {
            Object v = value();
            ws();
            if (i != s.length()) {
                throw new IllegalArgumentException("fin de message attendue");
            }
            return v;
        }

        private void ws() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) {
                i++;
            }
        }

        private Object value() {
            ws();
            if (i >= s.length()) {
                throw new IllegalArgumentException("valeur attendue");
            }
            char c = s.charAt(i);
            switch (c) {
                case '{':
                    return object();
                case '[':
                    return array();
                case '"':
                    return string();
                case 't':
                    return literal("true", Boolean.TRUE);
                case 'f':
                    return literal("false", Boolean.FALSE);
                case 'n':
                    return literal("null", null);
                default:
                    return number();
            }
        }

        private Object literal(String word, Object v) {
            if (!s.startsWith(word, i)) {
                throw new IllegalArgumentException("littéral inattendu");
            }
            i += word.length();
            return v;
        }

        private Map<String, Object> object() {
            Map<String, Object> m = new LinkedHashMap<>();
            expect('{');
            ws();
            if (s.charAt(i) == '}') {
                i++;
                return m;
            }
            while (true) {
                String k = string();
                expect(':');
                m.put(k, value());
                ws();
                char c = s.charAt(i++);
                if (c == '}') {
                    return m;
                }
                if (c != ',') {
                    throw new IllegalArgumentException("',' ou '}' attendu");
                }
            }
        }

        private List<Object> array() {
            List<Object> l = new ArrayList<>();
            expect('[');
            ws();
            if (s.charAt(i) == ']') {
                i++;
                return l;
            }
            while (true) {
                l.add(value());
                ws();
                char c = s.charAt(i++);
                if (c == ']') {
                    return l;
                }
                if (c != ',') {
                    throw new IllegalArgumentException("',' ou ']' attendu");
                }
            }
        }

        private String string() {
            expect('"');
            StringBuilder b = new StringBuilder();
            while (true) {
                char c = s.charAt(i++);
                if (c == '"') {
                    return b.toString();
                }
                if (c != '\\') {
                    b.append(c);
                    continue;
                }
                char e = s.charAt(i++);
                switch (e) {
                    case '"', '\\', '/' -> b.append(e);
                    case 'b' -> b.append('\b');
                    case 'f' -> b.append('\f');
                    case 'n' -> b.append('\n');
                    case 'r' -> b.append('\r');
                    case 't' -> b.append('\t');
                    case 'u' -> {
                        b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                        i += 4;
                    }
                    default -> throw new IllegalArgumentException("échappement inconnu");
                }
            }
        }

        private Object number() {
            int start = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) {
                i++;
            }
            String n = s.substring(start, i);
            if (n.isEmpty()) {
                throw new IllegalArgumentException("valeur inattendue");
            }
            if (n.contains(".") || n.contains("e") || n.contains("E")) {
                return Double.parseDouble(n);
            }
            return Long.parseLong(n);
        }

        private void expect(char c) {
            ws();
            if (i >= s.length() || s.charAt(i) != c) {
                throw new IllegalArgumentException("'" + c + "' attendu");
            }
            i++;
        }
    }
}
