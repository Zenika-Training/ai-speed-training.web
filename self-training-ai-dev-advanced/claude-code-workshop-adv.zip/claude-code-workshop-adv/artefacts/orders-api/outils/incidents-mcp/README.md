# incidents-mcp — serveur MCP d'exercice

Utilisé au module B du workshop Claude Code avancé. Il imite une source d'incidents de
production, comme un MCP raccordé à un outil de gestion des incidents. **Toutes les données sont
fictives.** Il ne fait partie ni de l'API ni de son build Maven.

- Lancement : `java IncidentsMcp.java` (JDK 21, aucune dépendance).
- Transport : stdio, un message JSON-RPC 2.0 par ligne.
- Outils : `lister_incidents` (filtre facultatif `service`) et `lire_incident` (paramètre
  `incident`, par exemple `INC-4133`).
