package com.workshop.orders.store;

import com.workshop.orders.model.Order;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class OrderStore {
    private final Map<Long, Order> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    public List<Order> findAll() { return new ArrayList<>(store.values()); }
    public Optional<Order> findById(Long id) { return Optional.ofNullable(store.get(id)); }
    public List<Order> findByCustomerId(String customerId) {
        return store.values().stream()
                .filter(o -> customerId.equals(o.getCustomerId())).toList();
    }
    public Order save(Order order) {
        if (order.getId() == null) order.setId(sequence.getAndIncrement());
        store.put(order.getId(), order);
        return order;
    }
    public boolean deleteById(Long id) { return store.remove(id) != null; }
}
