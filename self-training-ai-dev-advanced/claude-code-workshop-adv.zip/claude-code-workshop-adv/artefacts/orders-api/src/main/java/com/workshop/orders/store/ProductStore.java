package com.workshop.orders.store;

import com.workshop.orders.model.Product;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class ProductStore {
    private final Map<Long, Product> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    public ProductStore() {
        save(new Product(null, "Laptop Pro 15", "electronics", 1299.99, 25));
        save(new Product(null, "Wireless Mouse", "electronics", 49.99, 100));
        save(new Product(null, "Standing Desk", "furniture", 599.99, 10));
        save(new Product(null, "Coffee Mug", "accessories", 12.99, 200));
    }

    public List<Product> findAll() { return new ArrayList<>(store.values()); }
    public Optional<Product> findById(Long id) { return Optional.ofNullable(store.get(id)); }
    public List<Product> findByCategory(String cat) {
        return store.values().stream().filter(p -> cat.equalsIgnoreCase(p.getCategory())).toList();
    }
    public Product save(Product p) {
        if (p.getId() == null) p.setId(sequence.getAndIncrement());
        store.put(p.getId(), p);
        return p;
    }
    public boolean deleteById(Long id) { return store.remove(id) != null; }
}
