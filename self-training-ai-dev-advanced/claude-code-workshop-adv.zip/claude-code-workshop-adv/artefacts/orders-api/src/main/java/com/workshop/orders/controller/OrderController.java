package com.workshop.orders.controller;

import com.workshop.orders.model.Order;
import com.workshop.orders.store.OrderStore;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/orders")
public class OrderController {
    private final OrderStore orderStore;

    public OrderController(OrderStore orderStore) {
        this.orderStore = orderStore;
    }

    @GetMapping
    public List<Order> getAll() { return orderStore.findAll(); }

    @GetMapping("/{id}")
    public ResponseEntity<Order> getById(@PathVariable Long id) {
        return orderStore.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/customer/{customerId}")
    public List<Order> getByCustomer(@PathVariable String customerId) {
        return orderStore.findByCustomerId(customerId);
    }

    @PostMapping
    public ResponseEntity<Order> create(@Valid @RequestBody Order order) {
        return ResponseEntity.status(HttpStatus.CREATED).body(orderStore.save(order));
    }

    @PatchMapping("/{id}/status")
    public ResponseEntity<Order> updateStatus(@PathVariable Long id,
                                              @RequestParam Order.OrderStatus status) {
        return orderStore.findById(id).map(o -> {
            o.setStatus(status);
            return ResponseEntity.ok(orderStore.save(o));
        }).orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> delete(@PathVariable Long id) {
        if (!orderStore.deleteById(id))
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(Map.of("message", "Order deleted"));
    }
}
