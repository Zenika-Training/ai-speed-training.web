package com.workshop.orders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.workshop.orders.model.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class ProductControllerTest {
    @Autowired MockMvc mockMvc;
    @Autowired ObjectMapper objectMapper;

    @Test
    void getAll_returnsOk() throws Exception {
        mockMvc.perform(get("/products"))
               .andExpect(status().isOk());
    }

    @Test
    void create_returnsCreated() throws Exception {
        Product p = new Product(null, "Test", "electronics", 9.99, 5);
        mockMvc.perform(post("/products")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(p)))
               .andExpect(status().isCreated());
    }
}
