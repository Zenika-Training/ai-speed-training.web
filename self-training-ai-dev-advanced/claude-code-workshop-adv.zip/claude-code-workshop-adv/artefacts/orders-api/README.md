# Orders API - Spring Boot

API e-commerce de gestion de commandes et produits - workshop Claude Code avancé.

## Démarrage

    mvn spring-boot:run

## Tests

    mvn test

`.mvn/maven.config` active le mode silencieux de Maven : un succès n'affiche presque rien, un
échec affiche le test en cause. La sortie des tests est rangée dans `target/surefire-reports/`.

## Endpoints Produits

- GET    /products              - Lister (filtrable ?category=)
- GET    /products/{id}         - Détail
- POST   /products              - Créer
- PUT    /products/{id}         - Modifier
- DELETE /products/{id}         - Supprimer

## Endpoints Commandes

- GET    /orders                - Lister
- GET    /orders/{id}           - Détail
- GET    /orders/customer/{id}  - Par client
- POST   /orders                - Créer
- PATCH  /orders/{id}/status    - Changer statut
- DELETE /orders/{id}           - Supprimer

## Health

    curl http://localhost:8080/actuator/health

## Outils d'exercice

`outils/incidents-mcp/` contient un serveur MCP d'exercice, utilisé au module B du workshop.
Il n'est pas compilé avec l'API.
