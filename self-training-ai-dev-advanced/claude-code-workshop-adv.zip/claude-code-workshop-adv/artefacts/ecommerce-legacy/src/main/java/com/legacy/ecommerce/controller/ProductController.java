package com.legacy.ecommerce.controller;

import com.legacy.ecommerce.model.Product;
import com.legacy.ecommerce.store.ProductStore;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class ProductController {
    private final ProductStore productStore;

    public ProductController(ProductStore productStore) { this.productStore = productStore; }

    @GetMapping("/products")
    public List<Product> getAll() { return productStore.findAll(); }

    @GetMapping("/products/{id}")
    public ResponseEntity<Product> getById(@PathVariable Long id) {
        return productStore.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/products/featured")
    public List<Product> getFeatured() {
        return productStore.findAll().stream()
                .filter(p -> p.getStock() > 20).toList();
    }

    @PostMapping("/products")
    public ResponseEntity<Product> create(@RequestBody Product product) {
        if (product.getPrice() < 0) {
            product.setPrice(0);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(productStore.save(product));
    }

    @PutMapping("/products/{id}")
    public ResponseEntity<Product> update(@PathVariable Long id, @Valid @RequestBody Product product) {
        if (productStore.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        product.setId(id);
        return ResponseEntity.ok(productStore.save(product));
    }
}
