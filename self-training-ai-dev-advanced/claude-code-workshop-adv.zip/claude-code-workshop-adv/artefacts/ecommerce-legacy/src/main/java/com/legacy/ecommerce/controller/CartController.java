package com.legacy.ecommerce.controller;

import com.legacy.ecommerce.model.Cart;
import com.legacy.ecommerce.model.CartItem;
import com.legacy.ecommerce.store.CartStore;
import com.legacy.ecommerce.store.ProductStore;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping("/cart")
public class CartController {
    private final CartStore cartStore;
    private final ProductStore productStore;

    public CartController(CartStore cartStore, ProductStore productStore) {
        this.cartStore = cartStore;
        this.productStore = productStore;
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<Cart> getCart(@PathVariable String customerId) {
        return cartStore.findByCustomerId(customerId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/{customerId}/items")
    public ResponseEntity<Map<String, String>> addItem(@PathVariable String customerId,
                                                       @RequestBody CartItem item) {
        cartStore.addItem(customerId, item);
        return ResponseEntity.ok(Map.of("message", "Item added"));
    }

    @PostMapping("/{customerId}/checkout")
    public ResponseEntity<Map<String, String>> checkout(@PathVariable String customerId) {
        Optional<Cart> cart = cartStore.findByCustomerId(customerId);
        if (cart.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        if (cart.get().getItems().isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "Cart is empty"));
        }
        for (CartItem item : cart.get().getItems()) {
            productStore.updateStock(item.getProductId(), -item.getQuantity());
        }
        cartStore.clearCart(customerId);
        return ResponseEntity.ok(Map.of("message", "Order placed"));
    }
}
