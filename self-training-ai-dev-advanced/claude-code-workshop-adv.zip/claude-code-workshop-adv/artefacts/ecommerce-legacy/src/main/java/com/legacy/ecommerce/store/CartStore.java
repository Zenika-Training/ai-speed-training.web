package com.legacy.ecommerce.store;

import com.legacy.ecommerce.model.Cart;
import com.legacy.ecommerce.model.CartItem;
import org.springframework.stereotype.Component;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class CartStore {
    private final Map<String, Cart> store = new ConcurrentHashMap<>();

    public Optional<Cart> findByCustomerId(String customerId) {
        return Optional.ofNullable(store.get(customerId));
    }

    public Cart getOrCreate(String customerId) {
        return store.computeIfAbsent(customerId, Cart::new);
    }

    public void addItem(String customerId, CartItem item) {
        Cart cart = getOrCreate(customerId);
        cart.getItems().add(item);
    }

    public void clearCart(String customerId) {
        store.remove(customerId);
    }
}
