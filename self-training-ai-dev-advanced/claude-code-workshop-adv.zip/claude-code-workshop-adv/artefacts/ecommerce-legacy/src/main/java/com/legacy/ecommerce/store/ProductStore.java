package com.legacy.ecommerce.store;

import com.legacy.ecommerce.model.Product;
import org.springframework.stereotype.Component;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class ProductStore {
    private final Map<Long, Product> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(0);

    public ProductStore() {
        save(new Product(null, "Laptop", "electronics", 999.0, 10));
        save(new Product(null, "Phone", "electronics", 599.0, 25));
        save(new Product(null, "Desk", "furniture", 299.0, 5));
    }

    public List<Product> findAll() { return new ArrayList<>(store.values()); }
    public Optional<Product> findById(Long id) { return Optional.ofNullable(store.get(id)); }

    public Product save(Product p) {
        if (p.getId() == null) p.setId(sequence.getAndIncrement());
        store.put(p.getId(), p);
        return p;
    }

    public boolean updateStock(Long id, int delta) {
        Product p = store.get(id);
        if (p == null) return false;
        p.setStock(p.getStock() + delta);
        return true;
    }
}
