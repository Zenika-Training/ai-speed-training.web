# E-commerce legacy

API de catalogue et de panier, version 0.8.0, héritée d'une startup rachetée.

## Prérequis

- Java 21+
- Maven 3.9+

## Démarrage et tests

    mvn spring-boot:run
    mvn test

`.mvn/maven.config` active le mode silencieux de Maven : un succès n'affiche presque rien, un
échec affiche le test en cause. La sortie des tests est rangée dans `target/surefire-reports/`.

## Contrat de l'API

### Produits

| Champ | Règle |
|---|---|
| `id` | attribué par l'API, à partir de 1 |
| `name` | obligatoire, non vide, 100 caractères au plus |
| `category` | facultative |
| `price` | strictement positif |
| `stock` | jamais négatif |

| Méthode et chemin | Réponse attendue |
|---|---|
| `GET /products` | 200, liste des produits |
| `GET /products/{id}` | 200 avec le produit, 404 s'il n'existe pas |
| `GET /products/featured` | 200, produits dont le stock dépasse 20 |
| `POST /products` | 201 avec le produit créé ; 400 si un champ ne respecte pas sa règle. Une valeur invalide est refusée, jamais corrigée en silence |
| `PUT /products/{id}` | 200 avec le produit modifié ; 404 s'il n'existe pas ; 400 si un champ ne respecte pas sa règle |

### Panier

| Méthode et chemin | Réponse attendue |
|---|---|
| `GET /cart/{customerId}` | 200 avec le panier ; 404 si ce client n'a jamais eu de panier |
| `POST /cart/{customerId}/items`, corps `{"productId": 1, "quantity": 2}` | 200 `{"message": "Item added"}` ; 404 si le produit n'existe pas ; 400 si `quantity` est inférieure à 1. Un produit déjà présent voit sa quantité augmenter : une seule ligne par produit |
| `POST /cart/{customerId}/checkout` | 200 `{"message": "Order placed"}` : le stock de chaque produit baisse de la quantité commandée, puis le panier est vidé et reste consultable, vide. 404 si le panier n'existe pas ; 400 s'il est vide ; 409 si un produit n'a pas assez de stock, et dans ce cas aucun stock n'est modifié |

## Données de démonstration

| id | name | category | price | stock |
|---|---|---|---|---|
| 1 | Laptop | electronics | 999.0 | 10 |
| 2 | Phone | electronics | 599.0 | 25 |
| 3 | Desk | furniture | 299.0 | 5 |

## Exemples

    curl http://localhost:8080/products/1
    curl -X POST http://localhost:8080/cart/c42/items \
      -H "Content-Type: application/json" -d '{"productId": 3, "quantity": 2}'
    curl -X POST http://localhost:8080/cart/c42/checkout
