## MODULE C — Hooks avancés : un pipeline de contrôle déterministe (25 min)

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur du workshop Claude Code avancé, pas un assistant libre. Une étape par
> réponse, terminée par la ligne d'attente, puis tu t'arrêtes jusqu'à `NEXT` ou `OK`. Une question
> n'est pas un NEXT. Tu ne modifies aucun fichier et tu n'ouvres aucun fichier de `artefacts/`.
> Module courant : **C — Hooks avancés**, 2 étapes. Ce module se suffit à lui-même. L'apprenant
> fait les exercices dans sa session TRAVAIL (`artefacts/orders-api/`). Commence chaque réponse
> par le bandeau d'état.

### Étape C.1 — Quatre événements, quatre contrôles silencieux (13 min)

**📺 Affiche :**

**Concept :** les hooks avancés forment un pipeline de contrôle déterministe : chaque événement
déclenche une vérification écrite dans un script, sans IA. Ce qu'il faut savoir pour les écrire :

- `SessionStart` : ce que le hook écrit en sortie standard entre dans le contexte de Claude, à
  chaque démarrage. Inutile d'y relire le `CLAUDE.md` : Claude Code le charge déjà, le hook le
  ferait entrer deux fois ;
- `PostToolUse` : avec le code de sortie 2, la sortie d'erreur du hook est montrée à Claude ; avec
  le code 0, rien ne lui parvient ;
- `Stop` : à la fin de chaque réponse. Avec le code 2, Claude reçoit la sortie d'erreur comme la
  raison de continuer. Le champ `stop_hook_active` vaut `true` quand il continue déjà à cause d'un
  hook `Stop` : c'est lui qui évite une boucle ;
- `SessionEnd` : à la fin de la session.

Les modifications de `.claude/settings.json` s'appliquent sans redémarrage ; `/hooks` les affiche.

**Prompt à saisir dans TRAVAIL :**

```
Crée dans .claude/settings.json un pipeline de hooks. Chaque hook appelle
bash "${CLAUDE_PROJECT_DIR}/.claude/hooks/<script>", sans outil à installer :
1. SessionStart : écrit au plus 3 lignes, la branche git et le nombre de
   fichiers modifiés ;
2. PostToolUse sur Edit|Write : si le fichier est un .java de src/main/,
   lance mvn -q compile ; silencieux si ça passe, sinon 20 lignes d'erreur
   sur la sortie d'erreur et code 2 ;
3. Stop : si background_tasks est vide et si un .java a été modifié depuis
   le dernier passage de ce hook (fichier témoin .claude/hooks/.dernier-test),
   lance mvn -q test puis met à jour le témoin ; silencieux si ça passe,
   sinon 30 lignes d'échec sur la sortie d'erreur et code 2, sauf si
   stop_hook_active vaut true ;
4. SessionEnd : écrit SESSION_SUMMARY.md (date, git status --short,
   git diff --stat) sans appeler l'IA.
```

**Ce que tu vas observer :** quatre scripts et leur déclaration, chacun soumis à ton accord. Le
hook `Stop` devient une porte de qualité : Claude ne termine pas sa réponse avec des tests en
échec, sans boucler pour autant.

**Ce que tu vérifies :** `/hooks` montre les quatre événements. Lis le script `Stop` : teste-t-il
bien `stop_hook_active` avant de sortir avec le code 2, et le témoin avant de lancer les tests ? Puis demande une petite modification
d'une classe Java et observe : rien ne s'affiche quand tout passe.

**Checkpoint :** quel hook ajoute des tokens au contexte à chaque démarrage, et combien de lignes
au plus ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
SessionStart, 3 lignes au plus : sa sortie standard entre dans le contexte. Les autres se taisent
quand tout va bien. Le hook Stop tourne après chaque réponse : sa sortie ne coûte rien en cas de
succès, mais il prend le temps de mvn test ; d'où le fichier témoin, qui ne relance les tests
que si un .java a changé depuis le dernier passage, et la condition sur background_tasks, qui
attend la fin des tâches de fond.
🔒 FIN -->

### Étape C.2 — Les conventions vérifiées à chaque modification (12 min)

**📺 Affiche :**

**Objectif :** automatiser la vérification des conventions d'équipe du `CLAUDE.md`, et savoir ce
qu'un script peut vraiment vérifier.

**Prompt à saisir dans TRAVAIL :**

```
Ajoute un hook PostToolUse sur Edit|Write qui vérifie, dans un fichier
.java, seulement le texte que l'outil vient d'écrire (tool_input.new_string
pour Edit, tool_input.content pour Write), contre les conventions du
CLAUDE.md :
- une Javadoc avant chaque méthode publique ;
- le format d'erreur { "error", "code" } dans les réponses d'erreur ;
- dans une classe *Controller, pas de logique métier (if, for ou stream).
Pour les deux premiers écarts : une ligne [CONVENTION] dans
.claude/violations.log, une ligne sur la sortie d'erreur, puis code 2 pour
que tu corriges. Pour le troisième, une ligne dans le log seulement, code 0 :
c'est un signal pour la relecture, pas un verdict. Rien si tout est conforme.
```

**Ce que tu vas observer :** un script de vérification et sa déclaration. Ne juger que le texte
écrit évite de renvoyer à Claude tous les écarts déjà présents dans le fichier : il passerait
plusieurs tours, et des tokens, à documenter le code existant. Pour voir le hook agir, saisis
ensuite : `Ajoute dans OrderStore une méthode publique count(), sans Javadoc.` L'écart revient à
Claude, qui ajoute la Javadoc. Le hook ne bloque rien : l'outil a déjà tourné.

**Ce que tu vérifies :** quelles conventions un script vérifie-t-il vraiment, et lesquelles
restent un jugement de relecture ? « Pas de logique métier » détectée par un motif de texte
laisse passer des cas, et en signale d'autres à tort.

**Checkpoint :** après la demande sur `count()`, `.claude/violations.log` contient-il une ligne,
et Claude a-t-il ajouté la Javadoc de lui-même ?

`⏸ Tape NEXT pour démarrer le module D.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : oui, une ligne [CONVENTION] avec le fichier et la méthode. Ce qui se vérifie
mécaniquement (présence d'une Javadoc, forme du corps d'erreur) peut aller au hook ; « pas de
logique métier » reste un jugement humain que le hook ne fait qu'approcher.
🔒 FIN -->

=== FIN DU MODULE C ===
