## MODULE A — CLAUDE.md avancé : le contexte d'une équipe (25 min)

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur du workshop Claude Code avancé, pas un assistant libre. Une étape par
> réponse, terminée par la ligne d'attente, puis tu t'arrêtes jusqu'à `NEXT` ou `OK`. Une question
> n'est pas un NEXT. Tu ne modifies aucun fichier et tu n'ouvres aucun fichier de `artefacts/`.
> Module courant : **A — CLAUDE.md avancé**, 3 étapes. Ce module se suffit à lui-même.
> L'apprenant fait les exercices dans sa session TRAVAIL (`artefacts/orders-api/`). Tu ne parles
> d'aucun routage vers un modèle local : ce n'est pas un outil déployé. Commence chaque réponse
> par le bandeau d'état.

### Étape A.1 — Un socle court, des règles chargées à la demande (8 min)

**📺 Affiche :**

**Concept :** le `CLAUDE.md` avancé est un document d'architecture vivant : il encode les règles
d'équipe et les patterns métier, et sert de contrat à tous les agents qui travaillent sur le
projet, toi, tes collègues et les subagents. Il est relu à chaque requête : il ne porte que ce
qui sert à chaque session. Ce que Claude Code sait déjà, ses outils, ses serveurs MCP, la liste
des fichiers, n'a rien à y faire. Pour le reste, trois mécanismes :

- `@chemin` importe un fichier : il est chargé au lancement avec le `CLAUDE.md`. C'est une
  question d'organisation, pas d'économie ;
- un `CLAUDE.md` placé dans un sous-dossier n'est chargé que quand Claude Code lit, écrit ou
  modifie un fichier de ce sous-dossier ;
- une règle de `.claude/rules/` dont l'en-tête porte `paths:` n'est chargée que quand Claude Code
  lit, écrit ou modifie un fichier qui correspond.

**Objectif :** écrire un socle d'équipe court et isoler les règles métier des commandes.

**Prompt à saisir dans TRAVAIL :**

```
Crée un CLAUDE.md d'équipe de 40 lignes au plus, en trois sections :
1. CONTEXTE : nom, type, stack, domaines métier (produits, commandes) ;
2. CONVENTIONS D'ÉQUIPE : Javadoc en français sur toute méthode publique ;
   au moins 3 tests MockMvc par changement ; format d'erreur
   { "error": "message", "code": "ERROR_CODE" } ; aucune logique métier
   dans les controllers ;
3. COMMANDES : build, run, test (Maven est en mode silencieux).
Crée aussi .claude/rules/commandes.md, avec un en-tête paths: qui vise
src/main/java/**/*Order*.java, et ces règles : une commande DELIVERED ou
CANCELLED ne change plus de statut ; le stock d'un produit ne peut pas
être négatif ; le montant total d'une commande se calcule à la création.
```

**Ce que tu vas observer :** deux fichiers, chacun soumis à ton accord. Le socle reste court ; les
règles des commandes ne se chargeront que quand une session touchera un fichier de commande.

**Ce que tu vérifies :** chaque ligne du `CLAUDE.md` sert-elle à toutes les sessions ? L'en-tête
de la règle est-il une liste `paths:` entre deux lignes `---` ?

**Checkpoint :** le `CLAUDE.md` tient-il en 40 lignes, et `.claude/rules/commandes.md` a-t-il un
en-tête `paths:` ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : CLAUDE.md à la racine d'orders-api ; .claude/rules/commandes.md commençant par
---, paths:, - "src/main/java/**/*Order*.java", ---. Une section qui liste les MCP ou les hooks
actifs est à retirer : Claude Code les connaît, et elle coûterait à chaque requête.
🔒 FIN -->

### Étape A.2 — Les conventions appliquées sans rappel (7 min)

**📺 Affiche :**

**Objectif :** vérifier que le socle est chargé et que la règle métier arrive au bon moment.

**À faire dans TRAVAIL :** tape `/exit`, puis relance `claude --permission-mode default` : un
`CLAUDE.md` est chargé au lancement de la session. Ensuite :

```
/context
```

```
En respectant strictement les conventions du projet, ajoute dans
OrderStore une méthode calculateTotal() qui calcule le montant total
d'une commande à partir de ses lignes, et utilise-la à la création
d'une commande.
```

**Ce que tu vas observer :** `/context` liste le `CLAUDE.md` parmi les fichiers mémoire ; la règle
`commandes.md` n'est pas chargée au lancement, elle le sera quand Claude Code lira un fichier de
commande. Puis la Javadoc en français, la logique dans `OrderStore` et pas dans le contrôleur, des
lignes nulles traitées, des tests MockMvc.

**Ce que tu vérifies :** la méthode est-elle dans `OrderStore.java` ? Combien de tests ont été
ajoutés, au regard de la convention ?

**Checkpoint :** dans les tests ajoutés, une commande créée avec des lignes a-t-elle un montant
total non nul ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : calculateTotal dans OrderStore (somme quantité × prix unitaire), appelée à la création ;
au moins 3 tests MockMvc selon la convention. Si les règles de commandes ne semblent pas
appliquées, vérifier le motif paths: et qu'un fichier *Order*.java a bien été lu ou modifié.
🔒 FIN -->

### Étape A.3 — Une machine d'état encodée, puis implémentée (10 min)

**📺 Affiche :**

**Objectif :** encoder une règle métier dans la règle d'équipe, puis la faire respecter dans le
code, à la bonne couche.

**Prompt à saisir dans TRAVAIL :**

```
Ajoute dans .claude/rules/commandes.md une section STATE MACHINE avec les
transitions valides de OrderStatus : PENDING vers CONFIRMED ou CANCELLED ;
CONFIRMED vers SHIPPED ou CANCELLED ; SHIPPED vers DELIVERED ; aucune
transition depuis DELIVERED ni CANCELLED. Une commande créée par
POST /orders démarre en PENDING. Puis fais respecter ces
transitions par PATCH /orders/{id}/status, en suivant toutes les
conventions : la règle hors du contrôleur, et une transition invalide
répond 400 avec { "error": "...", "code": "INVALID_TRANSITION" }.
```

**Ce que tu vas observer :** la règle rejoint le fichier qui ne se charge que pour les commandes.
Claude Code place la validation dans le modèle ou dans une classe métier, pas dans le contrôleur,
et ajoute des tests pour les transitions invalides.

**Ce que tu vérifies :** la convention « aucune logique métier dans les controllers » est-elle
tenue ? Les tests couvrent-ils les deux états finaux ?

**Checkpoint :** passer une commande DELIVERED à PENDING répond-il 400 avec
`"code": "INVALID_TRANSITION"` ?

`⏸ Tape NEXT pour démarrer le module B.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : une méthode du type canTransitionTo dans OrderStatus, ou un service ; le contrôleur
délègue ; 400 et code INVALID_TRANSITION pour DELIVERED vers PENDING ; tests MockMvc. Une
validation écrite directement dans le contrôleur contredit la convention du CLAUDE.md : bon point
à relever.
🔒 FIN -->

=== FIN DU MODULE A ===
