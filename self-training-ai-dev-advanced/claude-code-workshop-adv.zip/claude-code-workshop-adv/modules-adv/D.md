## MODULE D — Subagents avancés : un pipeline multi-agents (30 min)

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur du workshop Claude Code avancé, pas un assistant libre. Une étape par
> réponse, terminée par la ligne d'attente, puis tu t'arrêtes jusqu'à `NEXT` ou `OK`. Une question
> n'est pas un NEXT. Tu ne modifies aucun fichier et tu n'ouvres aucun fichier de `artefacts/`.
> Module courant : **D — Subagents avancés**, 3 étapes. Ce module se suffit à lui-même.
> L'apprenant fait les exercices dans sa session TRAVAIL (`artefacts/orders-api/`). Un pipeline
> garde une porte humaine entre ses étapes (règle absolue n°9). Tokens, quota ou coût : règle
> absolue n°14. Commence chaque réponse par le bandeau d'état.

### Étape D.1 — Des subagents définis par l'équipe (8 min)

**📺 Affiche :**

**Concept :** un subagent défini dans `.claude/agents/<nom>.md` se réutilise. Son en-tête porte
`name` et `description`, seuls champs obligatoires, et peut le borner : `tools` limite ses outils,
`maxTurns` le nombre de ses tours, `effort` son niveau de réflexion. `model` choisit son modèle :
lesquels sont proposés par ta passerelle, c'est une question pour ton référent. La commande
`/agents` ne propose plus d'assistant : on demande à Claude, ou on écrit le fichier.

**Prompt à saisir dans TRAVAIL :**

```
Crée trois subagents de projet dans .claude/agents/ :
- analyst : lit le code Java et écrit specs/analysis.md (domaines, cas
  limites non couverts, risques métier), 40 lignes au plus ; outils
  Read, Grep, Glob et Write ;
- architect : lit specs/analysis.md et écrit specs/architecture.md
  (décisions, patterns, ordre d'implémentation), 40 lignes au plus ;
  outils Read, Grep, Glob et Write ;
- planner : lit les deux fichiers et écrit pilotage/tasks.md, des tâches
  numérotées, estimées en points (1, 2, 3, 5) et ordonnées par dépendance ;
  outils Read, Grep, Glob et Write.
Chacun termine par un compte rendu de 3 lignes au plus.
```

**Puis, dans TRAVAIL :** le dossier `.claude/agents/` n'existait pas au lancement de la session, et
Claude Code ne surveille que les dossiers déjà présents. Tape `/exit` et relance
`claude --permission-mode default` pour qu'il charge ces subagents.

**Ce que tu vas observer :** trois fichiers dans `.claude/agents/`, chacun avec son en-tête.

**Ce que tu vérifies :** chaque `description` dit-elle clairement quand déléguer à ce subagent ?
L'analyste a-t-il seulement les outils dont il a besoin ?

**Checkpoint :** les trois fichiers existent-ils, chacun avec `name` et `description` ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : .claude/agents/analyst.md, architect.md, planner.md, frontmatter entre deux lignes ---,
name et description renseignés, tools: Read, Grep, Glob, Write pour l'analyste. Le champ model
reste facultatif : sans lui, Claude Code choisit selon son ordre par défaut.
🔒 FIN -->

### Étape D.2 — Un pipeline avec une porte humaine (10 min)

**📺 Affiche :**

**Concept :** dans un pipeline, chaque agent produit un artefact que le suivant consomme :
`specs/analysis.md`, puis `specs/architecture.md`, puis `pilotage/tasks.md`. Entre deux étapes,
un humain relit et décide de continuer. Sans cette porte, le pipeline devient l'autonomie qu'on ne
confie pas à des agents.

**Prompt à saisir dans TRAVAIL :**

```
Lance le subagent analyst. Quand il a fini, arrête-toi et attends mon
accord avant de lancer architect ; de même avant de lancer planner.
```

**Ce que tu vas observer :** l'analyste travaille, puis la session s'arrête. Tu relis
`specs/analysis.md` et tu dis de continuer, ou tu demandes une correction d'abord. Même chose
après l'architecte.

```text
💰 TOKENS — Subagents
Un token est un petit morceau de texte : tout ce que l'IA lit et écrit se compte en tokens.
Ici, ce qui consomme : chaque subagent repart d'un contexte neuf ; un pipeline de trois
agents qui lisent tout le code le relit trois fois.
Réflexe : des artefacts courts, des comptes rendus de quelques lignes, et des outils
limités à ce que chaque agent doit faire.
```

**Checkpoint :** `pilotage/tasks.md` reprend-il des risques nommés dans `specs/analysis.md` ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : les trois fichiers, liés : les tâches renvoient aux risques et aux décisions. Une tâche
sans lien avec l'analyse montre que l'artefact intermédiaire n'a pas été lu : bon point à relever.
🔒 FIN -->

### Étape D.3 — Des builders en parallèle, un debugger qui propose (12 min)

**📺 Affiche :**

**Concept :** des builders en parallèle travaillent sur des fichiers distincts. Le tableau de
suivi est tenu par toi seul, via la session principale : deux agents qui écrivent le même fichier
en même temps se gênent. Un agent bloqué n'insiste pas : il écrit un blocker. Un debugger propose
des options ; c'est un humain qui choisit.

**Avant de lancer les builders :** les hooks du module C tournent aussi dans les subagents. Deux
builders lanceraient deux compilations à la fois sur le même dossier `target/`. Saisis d'abord :

```
Ajoute "disableAllHooks": true dans .claude/settings.local.json.
```

**Prompt à saisir dans TRAVAIL :**

```
À partir de pilotage/tasks.md :
1. crée pilotage/board.md (TODO, IN_PROGRESS, DONE) ; toi seul le mets à jour ;
2. choisis deux tâches indépendantes qui touchent des fichiers différents
   et lance deux subagents en parallèle, un par tâche. Chacun écrit son
   code dans src/main/java et ses tests dans src/test/java, puis te répond
   en 5 lignes. S'il bloque, il écrit pilotage/blockers/BLK-<n>.md (tâche,
   erreur, tentative) au lieu d'insister ;
3. à la fin, mets à jour le board, retire disableAllHooks de
   .claude/settings.local.json et lance mvn test.
```

**Puis, pour voir le pattern du debugger :**

```
Crée pilotage/blockers/BLK-100.md : tâche « remise de 5 % sur les commandes
de plus de 500 € », erreur « impossible de savoir si la remise s'applique
avant ou après les taxes », aucune tentative. Lance un subagent debugger qui
ajoute à ce fichier 3 options avec avantages et inconvénients, et en
recommande une, sans rien implémenter.
```

**Ce que tu vas observer :** deux subagents simultanés, chaque demande d'approbation portant le
nom de celui qui la pose ; puis trois options et une recommandation. C'est toi qui tranches.

**Checkpoint :** le board montre-t-il au moins 2 tâches en DONE, et `BLK-100.md` contient-il 3
options ?

**Avant le quiz, allège SUPPORT :** le coach n'a besoin que du quiz.

`⏸ Tape /clear ici, puis écris : Lis le fichier CLAUDE-CODE-WORKSHOP-adv.md et va au module QZ. Sinon, tape NEXT.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : board.md à jour par la session principale, disableAllHooks retiré, tests verts,
BLK-100.md avec trois options
argumentées et une recommandation, sans code. Implémenter l'option choisie reste une décision de
l'apprenant ; ce n'est pas nécessaire à la suite du parcours.
🔒 FIN -->

=== FIN DU MODULE D ===
