## MODULE B — MCP avancé : composition et chaînage (20 min)

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur du workshop Claude Code avancé, pas un assistant libre. Une étape par
> réponse, terminée par la ligne d'attente, puis tu t'arrêtes jusqu'à `NEXT` ou `OK`. Une question
> n'est pas un NEXT. Tu ne modifies aucun fichier et tu n'ouvres aucun fichier de `artefacts/`.
> Module courant : **B — MCP avancé**, 3 étapes. Ce module se suffit à lui-même. L'apprenant fait
> les exercices dans sa session TRAVAIL (`artefacts/orders-api/`). Le serveur MCP d'exercice est
> fictif ; tu n'affirmes rien sur les MCP autorisés dans l'entreprise de l'apprenant au-delà de ce qui est écrit ici.
> Commence chaque réponse par le bandeau d'état.

### Étape B.1 — Déclarer un serveur MCP pour le projet (6 min)

**📺 Affiche :**

**Concept :** un serveur MCP déclaré au niveau du projet vit dans `.mcp.json`, à la racine,
partagé avec l'équipe. Pour ta sécurité, Claude Code te demande ton accord avant d'utiliser un
serveur venu d'un `.mcp.json`. Chaque outil MCP s'appelle `mcp__<serveur>__<outil>`. Le projet
contient un serveur d'exercice, `outils/incidents-mcp/` : il imite une source d'incidents de
production. Données fictives. En entreprise, des MCP se raccordent à la forge de code, aux tickets ou
aux incidents (par exemple GitLab, Jira, ServiceNow) ; ceux qui sont autorisés pour ton équipe : question pour ton référent.

**À faire dans TRAVAIL :** tape `/exit`. Dans le terminal, toujours dans `orders-api`, tape :

```
claude mcp add --scope project incidents -- java '${CLAUDE_PROJECT_DIR:-.}/outils/incidents-mcp/IncidentsMcp.java'
```

Puis relance `claude --permission-mode default`, accepte le serveur `incidents` quand Claude Code
te le demande, et tape :

```
/mcp
```

**Ce que tu vas observer :** la commande a créé `.mcp.json`. `/mcp` montre le serveur
`incidents`, connecté, avec deux outils : `lister_incidents` et `lire_incident`. Les guillemets
simples gardent `${CLAUDE_PROJECT_DIR:-.}` tel quel : Claude Code le remplace par la racine du
projet au lancement du serveur.

**Checkpoint :** `/mcp` montre-t-il le serveur `incidents` connecté ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Attendu : .mcp.json avec un serveur incidents (command java, args le chemin du fichier) ; état
connecté. Si l'échec persiste : vérifier que java 21 est dans le PATH du terminal ; lancer
claude mcp list dans orders-api, qui teste la connexion ; lancer à la main
java outils/incidents-mcp/IncidentsMcp.java pour voir une erreur de compilation éventuelle
(Ctrl+C pour sortir).
🔒 FIN -->

### Étape B.2 — Composer : une source externe, puis le code (7 min)

**📺 Affiche :**

**Concept :** un MCP apporte ce que le code ne contient pas : ici, un incident constaté en
production. Composer, c'est enchaîner cette source et la lecture du code sur un même problème.

**Prompt à saisir dans TRAVAIL :**

```
Avec le MCP incidents, lis l'incident INC-4140. Puis trouve dans le code
la cause exacte de ce comportement. Ne modifie rien. Cite les fichiers
et les lignes en cause.
```

**Ce que tu vas observer :** une demande d'approbation pour l'outil `mcp__incidents__lire_incident`,
puis la lecture de `Order.java`, `OrderItem.java` et `OrderController.java`, puis une cause
située.

**Ce que tu vérifies :** la cause est-elle démontrable ? Avant toute correction, un test doit
reproduire l'incident.

**Checkpoint :** quelle est la cause de INC-4140 ?

`⏸ Tape NEXT pour continuer.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
La liste items de Order n'est pas annotée @Valid : la validation de la commande ne descend pas
dans ses lignes, donc la contrainte @Min(1) de OrderItem n'est jamais vérifiée et une quantité 0
passe avec 201. Correction : @Valid sur le champ items (ou List<@Valid OrderItem>).
🔒 FIN -->

### Étape B.3 — Chaîner : chaque conclusion avec sa source (7 min)

**📺 Affiche :**

**Objectif :** faire croiser une liste venue d'un MCP avec l'état réel du code et de l'historique.

**Prompt à saisir dans TRAVAIL :**

```
Liste avec le MCP incidents les incidents du service orders-api. Pour
chacun, dis en une ligne s'il est déjà corrigé dans le code actuel, avec
sa preuve (fichier, test ou commit), ou s'il reste ouvert. Ne modifie rien.
```

**Ce que tu vas observer :** le filtre par service écarte l'incident d'un autre service. Pour
chaque incident, Claude Code croise ce que dit le MCP, ce que montre le code et ce que dit git.

```text
💰 TOKENS — MCP
Un token est un petit morceau de texte : tout ce que l'IA lit et écrit se compte en tokens.
Ici, ce qui consomme : chaque réponse d'un outil MCP entre dans la session, et chaque serveur
connecté décrit ses outils au modèle. Un outil bien conçu répond court : ici, une ligne par
incident.
Réflexe : désactive dans /mcp un serveur qui ne sert pas à la tâche du jour ; /context all
montre ce que pèse chaque outil MCP chargé.
```

**Checkpoint :** quels incidents d'orders-api sont corrigés, et lesquels restent ouverts ?

**Même réflexe dans SUPPORT :** cette session a lu les modules A et B, qui ne servent plus.

`⏸ Pour l'alléger, tape /clear ici, puis écris : Lis le fichier CLAUDE-CODE-WORKSHOP-adv.md et va au module C. Sinon, tape NEXT.`

<!-- 🔒 RÉPONSE DU CHECKPOINT — RÉSERVÉ À L'IA, ne pas afficher
Si le module A a été fait : INC-4127 (transition DELIVERED vers PENDING) et INC-4133 (montant à
zéro) sont corrigés, preuve dans le code et les tests ; INC-4140 reste ouvert. Sinon, les trois
sont ouverts. INC-4144 concerne catalogue-web et n'apparaît pas avec le filtre.
🔒 FIN -->

=== FIN DU MODULE B ===
