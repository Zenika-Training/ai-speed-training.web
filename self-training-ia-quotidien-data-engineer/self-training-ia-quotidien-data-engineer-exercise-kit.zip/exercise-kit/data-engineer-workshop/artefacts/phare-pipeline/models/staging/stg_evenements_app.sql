-- Les événements de l'application, un par ligne.
select
    evenement_id,
    sejour_id,
    type_evenement,
    cast(horodatage as timestamptz) as horodatage
from {{ source('app', 'evenements') }}
