-- Les départs, une ligne par séjour, avec ce que le client a fait dans l'application.
select
    d.sejour_id,
    d.hotel_code,
    d.date_depart,
    d.canal_depart,
    e.evenement_id is not null as a_utilise_app
from {{ ref('stg_pms_departs') }} as d
left join {{ ref('stg_evenements_app') }} as e
    on e.sejour_id = d.sejour_id
