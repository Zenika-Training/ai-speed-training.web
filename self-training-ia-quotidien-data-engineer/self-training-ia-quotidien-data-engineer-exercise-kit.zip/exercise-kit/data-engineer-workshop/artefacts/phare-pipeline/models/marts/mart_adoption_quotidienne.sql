-- Le taux d'adoption du départ express, par hôtel et par jour : la part des départs faits en express.
select
    hotel_code,
    date_depart,
    count(*) as departs,
    count(*) filter (where canal_depart = 'express') as departs_express,
    round(100.0 * count(*) filter (where canal_depart = 'express') / count(*), 1) as taux_adoption
from {{ ref('fct_departs') }}
group by hotel_code, date_depart
