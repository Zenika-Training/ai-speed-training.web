-- L'historique du taux d'adoption : chaque nuit, le pipeline ajoute la journée de la veille.
-- Pour charger une journée : dbt run -s hist_adoption_quotidienne --vars '{jour: 2026-10-14}'
{{ config(materialized='incremental') }}

select
    hotel_code,
    date_depart,
    departs,
    departs_express,
    taux_adoption,
    current_timestamp as charge_le
from {{ ref('mart_adoption_quotidienne') }}
{% if is_incremental() %}
where date_depart = '{{ var("jour", "2026-10-14") }}'
{% endif %}
