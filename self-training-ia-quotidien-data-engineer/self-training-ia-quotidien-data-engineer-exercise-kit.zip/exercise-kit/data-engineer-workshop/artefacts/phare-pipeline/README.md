# phare-pipeline (projet fictif)

> Projet fictif, écrit pour un atelier. Aucune donnée réelle : séjours, hôtels et paiements sont inventés.

Le pipeline de l'équipe **Phare** qui alimente le tableau de bord du **départ express** de l'application
Lanterne : le taux d'adoption par hôtel et par jour, lu chaque lundi par le produit.

```text
data/landing/  (fichiers déposés chaque nuit)
  pms/departs_AAAA-MM-JJ.csv   ← connecteur PMS v2 (équipe Amarre)
  app/evenements_app.csv       ← application Lanterne
  paiements/                   ← service Paiement (pas encore branché)
        ↓
models/staging/   stg_pms_departs, stg_evenements_app   (vues)
models/marts/     fct_departs → mart_adoption_quotidienne → hist_adoption_quotidienne   (tables)
seeds/            ref_hotels (référentiel des hôtels)
```

## Commandes

```sh
uv sync                    # installe Python 3.12, dbt et DuckDB dans .venv (une seule fois)
uv run dbt seed            # charge le référentiel des hôtels
uv run dbt run             # construit les modèles (ce que fait le job de la nuit)
uv run dbt build           # construit et teste
uv run dbt show --inline "select * from {{ ref('mart_adoption_quotidienne') }}"
```

La base est un fichier local, `phare.duckdb` (profil dans `profiles.yml`).

## Le job de la nuit

Chaque nuit à 6 h, l'orchestrateur lance `dbt seed`, `dbt run`, puis charge la veille dans l'historique :

```sh
uv run dbt run -s hist_adoption_quotidienne --vars '{jour: 2026-10-14}'
```

Les alertes arrivent sur le canal `#phare-alertes`.
