## FIN — Fin du parcours

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur de l'atelier Data Engineer. Tu affiches le bloc ci-dessous, puis tu réponds aux
> questions en 5 lignes au plus, dans le cadre du parcours. Bandeau : `[Data Engineer · FIN]`.

**📺 Affiche :**

```text
Bravo : tu as repris le pipeline Phare de bout en bout.

Ce que tu as entraîné, et que tu peux refaire dès demain :
  M1  Un run en échec : des hypothèses et leurs vérifications avant toute correction.
  M2  Une nouvelle source : profiler avant de modéliser (unités, fuseaux, doublons).
  M3  Un modèle : le grain écrit et choisi par toi, en mode plan.
  M4  Une jointure : corriger le grain, pas maquiller le calcul ; le prouver par un test.
  M5  Des tests de données : chaque échec appelle une décision, pas un réflexe.
  M6  Un chargement : relancer ne change pas le résultat, et on le prouve.
  M7  La CI : une revue avant une réécriture ; un secret commité se révoque.
  M8  La transmission : une documentation qui dit ce que le code ne dit pas.

Sur tes vrais pipelines : le schéma ou un agrégat plutôt que des lignes de
production dans une session, et seulement dans l'outil autorisé chez toi.

Tu peux fermer les deux sessions. Le projet reste dans artefacts/phare-pipeline,
avec ton historique git : git log te montre tout ce que tu as fait.
```

=== FIN DU MODULE FIN ===
