-- Les départs, une ligne par séjour, avec ce que le client a fait dans l'application.
-- Les événements sont agrégés par séjour avant la jointure : un séjour a souvent plusieurs événements.
with evenements_par_sejour as (
    select sejour_id, count(*) as evenements
    from {{ ref('stg_evenements_app') }}
    group by sejour_id
)

select
    d.sejour_id,
    d.hotel_code,
    d.date_depart,
    d.canal_depart,
    e.sejour_id is not null as a_utilise_app
from {{ ref('stg_pms_departs') }} as d
left join evenements_par_sejour as e
    on e.sejour_id = d.sejour_id
