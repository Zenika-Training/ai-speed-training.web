-- Un séjour qui quitte l'hôtel, tel que le PMS l'exporte : une ligne par séjour et par fichier reçu.
select
    sejour_id,
    hotel_code,
    coalesce(
        try_strptime(date_depart, '%Y-%m-%d'),
        try_strptime(date_depart, '%d/%m/%Y')
    )::date as date_depart,
    canal_depart,
    cast(montant_note as decimal(10, 2)) as montant_note,
    filename as fichier_source
from {{ source('pms', 'departs') }}
