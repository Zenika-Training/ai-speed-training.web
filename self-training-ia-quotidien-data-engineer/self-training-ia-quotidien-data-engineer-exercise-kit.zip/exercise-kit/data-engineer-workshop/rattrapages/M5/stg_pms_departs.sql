-- Un séjour qui quitte l'hôtel, tel que le PMS l'exporte : une ligne par séjour.
-- Le connecteur PMS v2 écrit les dates au format JJ/MM/AAAA depuis le 14 octobre (ticket ouvert chez Amarre).
-- Un séjour renvoyé dans un fichier plus récent n'est gardé qu'une fois : la version du fichier le plus récent.
-- Les hôtels de recette (TST-*) ne font pas partie des chiffres de production.
with source as (
    select * from {{ source('pms', 'departs') }}
    where hotel_code not like 'TST-%'
)

select
    sejour_id,
    hotel_code,
    coalesce(
        try_strptime(date_depart, '%Y-%m-%d'),
        try_strptime(date_depart, '%d/%m/%Y')
    )::date as date_depart,
    canal_depart,
    cast(montant_note as decimal(10, 2)) as montant_note,
    filename as fichier_source
from source
qualify row_number() over (partition by sejour_id order by filename desc) = 1
