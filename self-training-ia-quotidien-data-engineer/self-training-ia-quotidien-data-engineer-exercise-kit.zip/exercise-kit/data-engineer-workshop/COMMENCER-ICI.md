# Commencer ici — atelier « L'IA au quotidien — Data Engineer »

Ce dossier contient tout ce qu'il faut pour suivre l'atelier : le cours (`modules/`), un pipeline dbt
fictif sur DuckDB (`artefacts/phare-pipeline/`) et des corrections de secours (`rattrapages/`). Durée :
environ 3 h 30. Tu peux t'arrêter à la fin d'un module et reprendre plus tard.

Tu vas utiliser **deux sessions Claude Code, dans deux terminaux** :

- **SUPPORT** te guide pas à pas et ne modifie aucun fichier ;
- **TRAVAIL** est la session où tu fais les exercices, dans le projet, comme au quotidien.

L'atelier suppose que tu as déjà pris en main un agent de code (le module 1 « L'IA au quotidien du
développeur », ou un usage équivalent) : il ne réexplique ni les permissions, ni le mode plan.

## 1. Vérifie ton poste

Il te faut Claude Code avec ton accès ouvert, `uv`, git, et un terminal bash ou zsh (sous Windows,
Git Bash). `uv` installe lui-même Python 3.12, dbt et DuckDB dans le projet : rien d'autre à installer.

```sh
claude --version
uv --version
git --version
```

Pas de `uv` ? Voir https://docs.astral.sh/uv/getting-started/installation/ (une commande).

### Sans rien installer : le devcontainer

Avec Docker et VS Code (extension Dev Containers), ouvre ce dossier, puis « Reopen in Container ». Le
conteneur installe uv, git et Claude Code, et prépare l'environnement du projet : le premier `uv sync`
du parcours est immédiat. Au premier lancement de `claude`, connecte-toi.

## 2. Place ce dossier hors de tout projet

Ce dossier ne doit pas se trouver dans un projet qui contient un fichier `CLAUDE.md` : Claude Code le
chargerait aussi, et le parcours se comporterait autrement.

## 3. Lance la session SUPPORT

Ouvre un premier terminal **dans ce dossier** et lance :

```sh
claude --permission-mode default
```

Puis écris :

```
Lis le fichier ATELIER-DATA-ENGINEER.md et démarre.
```

## 4. Ouvre la session TRAVAIL quand SUPPORT te le demande

À l'étape 0.3, ouvre un second terminal **dans ce dossier** et tape :

```sh
cd artefacts/phare-pipeline
git init -q && git add -A && git commit -qm "Etat initial"
uv sync
uv run dbt seed
claude --permission-mode default
```

## 5. Reprendre plus tard

Relance `claude --permission-mode default` dans ce dossier, puis écris :

```
Lis le fichier ATELIER-DATA-ENGINEER.md et va au module M4.
```

Si un module que tu as sauté devait corriger le projet, son étape « Rattrapage » te donne la commande.

## Si quelque chose coince

- Un checkpoint ne passe pas : écris `KO` dans SUPPORT ; ce n'est pas bloquant.
- SUPPORT s'écarte du parcours : écris `RECADRE`.
- `uv sync` échoue : vérifie ton accès à internet (ou au miroir PyPI de ton entreprise), puis relance.
- Tout est cassé dans le projet : `git restore .` revient au dernier commit.

Le projet et ses données sont fictifs : tu peux les donner à l'agent sans risque.
