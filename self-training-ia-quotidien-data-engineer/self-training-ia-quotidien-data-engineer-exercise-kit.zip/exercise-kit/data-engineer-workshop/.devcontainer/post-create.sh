#!/usr/bin/env bash
# Prépare le conteneur de l'atelier : droits sur la configuration de Claude Code (volume persistant),
# installation de uv, puis environnement Python du projet, pour que le premier uv sync soit immédiat.
set -uo pipefail

sudo chown -R "$(id -u):$(id -g)" "$HOME/.claude" 2>/dev/null || true

curl -LsSf https://astral.sh/uv/install.sh | sh
export PATH="$HOME/.local/bin:$PATH"

if ! (cd artefacts/phare-pipeline && uv sync -q); then
  echo "Échec de uv sync : vérifie l'accès à PyPI, puis lance uv sync dans artefacts/phare-pipeline"
fi

echo "Conteneur prêt : uv, git et claude sont installés."
