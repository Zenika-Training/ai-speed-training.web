-- Fidélité par hôtel et par mois, version 2 : ca_ht devient chiffre_affaires_ht.
select
    s.hotel_code,
    h.ville,
    date_trunc('month', s.date_depart) as mois,
    count(*) as sejours_termines,
    count(distinct s.membre_id) as membres,
    sum(s.montant_ht) as chiffre_affaires_ht
from {{ ref('stg_sejours') }} as s
inner join {{ ref('ref_hotels') }} as h
    on h.hotel_code = s.hotel_code
where s.statut = 'termine'
    and not h.recette
group by 1, 2, 3
