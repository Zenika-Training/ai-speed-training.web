-- KPI mensuels du comité de direction, à partir des modèles intermédiaires.
with sejours as (
    select
        mois,
        sum(montant_ht) as ca_ht,
        count(*) as sejours_termines,
        sum(montant_ht) / count(*) as panier_moyen_ht
    from {{ ref('int_sejours_termines') }}
    group by mois
),

actifs as (
    select
        mois,
        count(distinct membre_id) as membres_actifs,
        count(distinct membre_id) filter (where niveau = 'or') as membres_or_actifs
    from {{ ref('int_membres_actifs_90j') }}
    group by mois
)

select
    s.mois,
    a.membres_actifs,
    a.membres_or_actifs,
    s.ca_ht,
    s.sejours_termines,
    round(s.panier_moyen_ht, 2) as panier_moyen_ht
from sejours as s
left join actifs as a on a.mois = s.mois
order by s.mois
