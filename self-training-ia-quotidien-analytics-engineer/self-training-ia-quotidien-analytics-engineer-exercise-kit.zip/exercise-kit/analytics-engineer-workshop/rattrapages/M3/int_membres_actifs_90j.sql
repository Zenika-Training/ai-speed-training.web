-- Membres actifs au sens du comité de direction : un séjour terminé dans les 90 jours qui précèdent la fin du mois.
-- Une ligne par mois et par membre actif. (Définition historique du comité, différente de la métrique membres_actifs.)
with mois as (
    select distinct mois, mois + interval 1 month - interval 1 day as fin_mois
    from {{ ref('int_sejours_termines') }}
)

select distinct
    m.mois,
    s.membre_id,
    s.niveau
from mois as m
inner join {{ ref('int_sejours_termines') }} as s
    on s.date_depart > m.fin_mois - interval 90 day
    and s.date_depart <= m.fin_mois
