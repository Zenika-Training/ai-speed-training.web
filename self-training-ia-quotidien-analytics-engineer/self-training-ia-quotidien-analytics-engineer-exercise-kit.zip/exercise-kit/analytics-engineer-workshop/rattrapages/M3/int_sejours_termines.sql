-- Les séjours terminés, une ligne par séjour, avec le niveau du membre. Base de tous les KPI de séjours.
select
    s.sejour_id,
    s.membre_id,
    m.niveau,
    s.hotel_code,
    s.date_depart,
    date_trunc('month', s.date_depart) as mois,
    s.montant_ht
from {{ ref('stg_sejours') }} as s
left join {{ ref('stg_membres') }} as m
    on m.membre_id = s.membre_id
where s.statut = 'termine'
