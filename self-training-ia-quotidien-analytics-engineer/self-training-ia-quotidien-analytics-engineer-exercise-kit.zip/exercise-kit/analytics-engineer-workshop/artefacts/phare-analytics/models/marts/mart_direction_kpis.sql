-- KPI mensuels du comité de direction. Écrit vite pour le comité de septembre, « à reprendre ».
with mois as (
    select distinct date_trunc('month', cast(date_depart as date)) as mois
    from {{ source('raw', 'sejours') }}
),

actifs as (
    -- membres actifs : un séjour terminé dans les 90 derniers jours à la fin du mois
    select
        m.mois,
        count(distinct s.membre_id) as membres_actifs
    from mois as m
    left join {{ source('raw', 'sejours') }} as s
        on cast(s.date_depart as date) > (m.mois + interval 1 month - interval 1 day) - interval 90 day
        and cast(s.date_depart as date) <= (m.mois + interval 1 month - interval 1 day)
        and s.statut = 'termine'
    group by 1
),

ca as (
    select
        date_trunc('month', cast(date_depart as date)) as mois,
        sum(cast(montant_ht as decimal(10, 2))) as ca_ht
    from {{ source('raw', 'sejours') }}
    where statut = 'termine'
    group by 1
),

sejours as (
    select
        date_trunc('month', cast(date_depart as date)) as mois,
        count(*) as sejours_termines,
        sum(cast(montant_ht as decimal(10, 2))) / count(*) as panier_moyen_ht
    from {{ source('raw', 'sejours') }}
    where statut = 'termine'
    group by 1
),

membres_or as (
    -- membres or actifs : même règle que plus haut, copiée
    select
        m.mois,
        count(distinct s.membre_id) as membres_or_actifs
    from mois as m
    left join {{ source('raw', 'sejours') }} as s
        on cast(s.date_depart as date) > (m.mois + interval 1 month - interval 1 day) - interval 90 day
        and cast(s.date_depart as date) <= (m.mois + interval 1 month - interval 1 day)
        and s.statut = 'termine'
    left join {{ source('raw', 'membres') }} as mb
        on mb.membre_id = s.membre_id
    where mb.niveau = 'or'
    group by 1
)

select
    m.mois,
    a.membres_actifs,
    o.membres_or_actifs,
    c.ca_ht,
    s.sejours_termines,
    round(s.panier_moyen_ht, 2) as panier_moyen_ht
from mois as m
left join actifs as a on a.mois = m.mois
left join membres_or as o on o.mois = m.mois
left join ca as c on c.mois = m.mois
left join sejours as s on s.mois = m.mois
order by m.mois
