-- Activité des membres pour l'équipe marketing fidélité. Écrit en juin 2026 par le marketing.
select
    date_trunc('month', date_depart) as mois,
    count(distinct membre_id) as membres_actifs,
    count(*) as sejours
from {{ ref('stg_sejours') }}
group by 1
