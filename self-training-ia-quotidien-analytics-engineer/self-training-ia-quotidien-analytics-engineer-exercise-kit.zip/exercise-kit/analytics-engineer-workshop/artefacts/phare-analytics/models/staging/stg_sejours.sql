-- Un séjour, typé. Une ligne par séjour.
select
    sejour_id,
    membre_id,
    hotel_code,
    cast(date_arrivee as date) as date_arrivee,
    cast(date_depart as date) as date_depart,
    statut,
    cast(montant_ht as decimal(10, 2)) as montant_ht,
    canal
from {{ source('raw', 'sejours') }}
