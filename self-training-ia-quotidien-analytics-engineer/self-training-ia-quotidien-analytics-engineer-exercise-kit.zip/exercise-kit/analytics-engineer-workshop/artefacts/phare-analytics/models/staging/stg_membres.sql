-- Un membre du programme de fidélité, typé. Une ligne par membre.
select
    membre_id,
    niveau,
    cast(date_adhesion as date) as date_adhesion
from {{ source('raw', 'membres') }}
