# phare-analytics (projet fictif)

> Projet fictif, écrit pour un atelier. Aucune donnée réelle : membres, séjours et hôtels sont inventés.

Les modèles analytiques de l'équipe **Phare** : à partir des données brutes déjà ingérées par les data engineers, des
modèles propres, testés et documentés pour les analystes et le métier (marketing fidélité, comité de direction,
directeurs d'hôtel).

```text
data/raw/        sejours.csv, membres.csv   (déjà ingérés)
seeds/           ref_hotels                 (référentiel, dont l'hôtel de recette TST-99)
models/staging/  stg_sejours, stg_membres   (vues)
models/marts/    mart_marketing_activite, mart_direction_kpis, mart_fidelite_hotel   (tables)
models/semantic/ time_spine_day             (calendrier de la couche sémantique)
bi/              requêtes SQL écrites directement dans Metabase
docs/            demandes du métier
revues/          pull requests à relire
scripts/audit.py photo / comparaison d'une table, pour une restructuration
```

## Commandes

```sh
uv sync                    # installe Python 3.12, dbt, DuckDB et MetricFlow dans .venv (une seule fois)
uv run dbt seed            # charge le référentiel des hôtels
uv run dbt build           # construit et teste
uv run dbt build --target prod      # l'environnement de production (une autre base locale)
uv run mf query --metrics <métrique> --group-by metric_time__month    # interroge la couche sémantique
uv run dbt ls -s +exposure:tableau_de_bord_fidelite                   # le lignage d'un tableau de bord
```

Les bases sont des fichiers locaux : `phare_dev.duckdb` (dev) et `phare_prod.duckdb` (prod), profils dans
`profiles.yml`.
