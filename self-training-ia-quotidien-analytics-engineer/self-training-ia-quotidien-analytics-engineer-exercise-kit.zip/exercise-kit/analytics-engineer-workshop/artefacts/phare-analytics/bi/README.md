# Requêtes des tableaux de bord (fictif)

Exports des questions Metabase qui ne lisent pas un mart mais écrivent leur propre SQL. Lecture seule : copiées ici
par Nadia pour garder une trace.
