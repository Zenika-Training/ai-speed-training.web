-- Question Metabase « Membres actifs du mois » (tableau de bord fidélité, carte du haut).
-- Écrite par un analyste en juillet 2026, directement sur la table des séjours.
select
    date_trunc('month', date_depart) as mois,
    count(*) as membres_actifs
from main.stg_sejours
group by 1
order by 1
