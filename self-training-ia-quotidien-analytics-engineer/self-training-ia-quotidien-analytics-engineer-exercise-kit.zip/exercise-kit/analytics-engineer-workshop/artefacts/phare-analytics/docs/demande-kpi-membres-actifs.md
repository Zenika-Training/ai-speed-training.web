# « Membres actifs » : notes de la réunion du 25 novembre 2026 (document fictif)

> Document fictif. Notes prises par Nadia (data analyst). Présents : Agathe (marketing fidélité, data owner du KPI),
> Mathilde (directrice du portefeuille), toi (analytics engineer).

- Mathilde : « Trois chiffres de membres actifs pour octobre dans trois tableaux. Je veux un seul chiffre. »
- Agathe : « Un membre actif, c'est quelqu'un qui est venu dans le mois. » Pour elle, le mois calendaire, pas
  une fenêtre glissante : « c'est ce qu'on pilote en campagne ».
- Question restée ouverte : un séjour **annulé** compte-t-il ? Agathe : « Non, il n'est pas venu. » Et un
  **no-show** ? « Non plus, je crois. » À confirmer.
- L'hôtel de recette `TST-99` : Nadia rappelle qu'il apparaît dans les données de production. Personne ne veut le
  compter.
- Le comité de direction garde-t-il sa fenêtre de 90 jours ? Mathilde : « Si on a une définition officielle, on
  la prend. Mais je veux savoir de combien le chiffre bouge. »
- Où vit la définition : « une seule fois, quelque part où Metabase et nous lisons la même chose ».
