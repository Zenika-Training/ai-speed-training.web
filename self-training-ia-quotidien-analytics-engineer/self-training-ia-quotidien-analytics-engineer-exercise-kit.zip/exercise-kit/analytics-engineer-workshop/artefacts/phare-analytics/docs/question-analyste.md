# Question d'Agathe sur le canal #phare-questions (document fictif)

> Document fictif. Message d'Agathe (marketing fidélité), le 27 novembre 2026, 9 h 12.

« Combien de membres or actifs à Lyon en octobre, et c'est mieux ou moins bien qu'en septembre ? J'en ai besoin
pour 11 h. Et la prochaine fois, je peux le trouver moi-même ? »
