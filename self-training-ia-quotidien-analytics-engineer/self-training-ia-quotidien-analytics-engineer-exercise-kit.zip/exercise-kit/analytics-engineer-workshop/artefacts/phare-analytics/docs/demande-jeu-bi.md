# Demande de Nadia — un jeu de données pour une page Metabase (document fictif)

> Document fictif. Message de Nadia (data analyst), le 26 novembre 2026.

Salut ! Les directeurs d'hôtel veulent une page « Fidélité par hôtel » : pour chaque mois, chaque ville et chaque
niveau de membre, les **membres actifs**, les **séjours terminés** et le **chiffre d'affaires HT**.

Je pensais écrire la requête directement dans Metabase, comme d'habitude. Mais on vient de définir les membres
actifs une bonne fois : tu peux me préparer un jeu de données propre, avec des noms que les directeurs
comprennent ? Ils aiment bien avoir une ligne « Total » par mois, aussi.
