"""Audit d'une restructuration : photographie une table avant, puis compare après.

    uv run python scripts/audit.py photo mart_direction_kpis      # avant de modifier
    uv run python scripts/audit.py compare mart_direction_kpis    # après uv run dbt run

La comparaison ignore l'ordre des lignes : elle dit combien de lignes manquent ou sont en trop de chaque côté.
"""
import sys

import duckdb

action, table = sys.argv[1], sys.argv[2]
con = duckdb.connect("phare_dev.duckdb")
if action == "photo":
    con.sql(f"create or replace table audit_{table} as select * from main.{table}")
    print(f"Photo prise : {con.sql(f'select count(*) from audit_{table}').fetchall()[0][0]} lignes dans audit_{table}.")
elif action == "compare":
    manquantes = con.sql(f"select * from audit_{table} except all select * from main.{table}").fetchall()
    en_trop = con.sql(f"select * from main.{table} except all select * from audit_{table}").fetchall()
    print(f"Lignes de la photo absentes après : {len(manquantes)}")
    print(f"Lignes nouvelles après : {len(en_trop)}")
    for ligne in manquantes[:5]:
        print("  avant :", ligne)
    for ligne in en_trop[:5]:
        print("  après :", ligne)
    print("Identique." if not manquantes and not en_trop else "Différent : explique chaque écart avant de continuer.")
