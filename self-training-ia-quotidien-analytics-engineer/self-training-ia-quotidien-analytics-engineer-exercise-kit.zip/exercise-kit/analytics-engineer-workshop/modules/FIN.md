## FIN — Fin du parcours

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur de l'atelier Analytics Engineer. Tu affiches le bloc ci-dessous, puis tu réponds aux
> questions en 5 lignes au plus, dans le cadre du parcours. Bandeau : `[Analytics Engineer · FIN]`.

**📺 Affiche :**

```text
Bravo : les modèles analytiques de Phare ont maintenant une seule définition par KPI.

Ce que tu as entraîné, et que tu peux refaire dès demain :
  M1  Trois chiffres : remonter le lignage de chacun avant de dire lequel est juste.
  M2  Un KPI : une définition validée par le métier, implémentée une seule fois.
  M3  Une restructuration : une photo avant, une comparaison après, aucun chiffre qui bouge.
  M4  Une revue : ce que le changement casse en aval, et ce qu'il retire.
  M5  Ce que lit la BI : un contrat, et une version pour renommer sans casser.
  M6  Un jeu de données : tiré des métriques ; un compte distinct ne s'additionne pas.
  M7  Une question : répondre avec la métrique, puis rendre l'analyste autonome.

Sur tes vrais modèles : le schéma ou un agrégat plutôt que des lignes de
production dans une session, et seulement dans l'outil autorisé chez toi.

Tu peux fermer les deux sessions. Le projet reste dans artefacts/phare-analytics,
avec ton historique git : git log te montre tout ce que tu as fait.
```

=== FIN DU MODULE FIN ===
