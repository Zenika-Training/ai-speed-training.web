import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app';
import { buildRoom, buildRooms } from './factories/room.factory';
import { createTestStore } from './factories/store.factory';

describe('GET /rooms', () => {
  it('returns an empty page when there is no room', async () => {
    const app = createApp(createTestStore());

    const res = await request(app).get('/rooms');

    expect(res.status).toBe(200);
    expect(res.body).toEqual({ items: [], nextCursor: null });
  });

  it('returns rooms sorted by id', async () => {
    const app = createApp(
      createTestStore({ rooms: [buildRoom({ id: 'room_c' }), buildRoom({ id: 'room_a' }), buildRoom({ id: 'room_b' })] }),
    );

    const res = await request(app).get('/rooms');

    expect(res.body.items.map((room: { id: string }) => room.id)).toEqual(['room_a', 'room_b', 'room_c']);
    expect(res.body.nextCursor).toBeNull();
  });

  it('walks every room exactly once by following nextCursor', async () => {
    const rooms = buildRooms(7);
    const app = createApp(createTestStore({ rooms }));

    const seen: string[] = [];
    let cursor: string | null = null;
    do {
      const res = await request(app)
        .get('/rooms')
        .query({ limit: 3, ...(cursor ? { cursor } : {}) });
      expect(res.status).toBe(200);
      seen.push(...res.body.items.map((room: { id: string }) => room.id));
      cursor = res.body.nextCursor;
    } while (cursor);

    expect(seen).toEqual(rooms.map((room) => room.id).sort());
  });

  it('returns nextCursor null on the last page', async () => {
    const app = createApp(createTestStore({ rooms: buildRooms(3) }));

    const res = await request(app).get('/rooms').query({ limit: 3 });

    expect(res.body.items).toHaveLength(3);
    expect(res.body.nextCursor).toBeNull();
  });

  it.each(['0', '101', 'abc'])('rejects limit=%s with a problem+json 400', async (limit) => {
    const app = createApp(createTestStore());

    const res = await request(app).get('/rooms').query({ limit });

    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/application\/problem\+json/);
    expect(JSON.parse(res.text)).toMatchObject({ status: 400, title: 'Bad Request' });
  });

  it('rejects a malformed cursor with a problem+json 400', async () => {
    const app = createApp(createTestStore({ rooms: buildRooms(2) }));

    const res = await request(app).get('/rooms').query({ cursor: 'not-a-cursor' });

    expect(res.status).toBe(400);
    expect(res.headers['content-type']).toMatch(/application\/problem\+json/);
  });
});

describe('GET /rooms/:id', () => {
  it('returns the room', async () => {
    const room = buildRoom({ name: 'Atlas' });
    const app = createApp(createTestStore({ rooms: [room] }));

    const res = await request(app).get(`/rooms/${room.id}`);

    expect(res.status).toBe(200);
    expect(res.body).toEqual(room);
  });

  it('returns a problem+json 404 for an unknown room', async () => {
    const app = createApp(createTestStore());

    const res = await request(app).get('/rooms/room_unknown');

    expect(res.status).toBe(404);
    expect(res.headers['content-type']).toMatch(/application\/problem\+json/);
    expect(JSON.parse(res.text)).toMatchObject({ status: 404, title: 'Not Found' });
  });
});
