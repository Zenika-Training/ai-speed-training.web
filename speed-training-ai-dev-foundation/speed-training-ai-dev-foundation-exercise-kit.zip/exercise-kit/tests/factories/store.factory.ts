import { Store } from '../../src/store/store';
import type { Seed } from '../../src/store/types';

/** A real in-memory store holding only the data the test gives it. */
export function createTestStore(seed: Partial<Seed> = {}): Store {
  return new Store({ rooms: seed.rooms ?? [], bookings: seed.bookings ?? [] });
}
