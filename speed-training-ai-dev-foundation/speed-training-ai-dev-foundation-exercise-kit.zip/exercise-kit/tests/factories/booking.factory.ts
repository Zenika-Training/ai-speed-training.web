import type { Booking } from '../../src/store/types';

let sequence = 0;

export function buildBooking(overrides: Partial<Booking> = {}): Booking {
  sequence += 1;
  return {
    id: `bk_t${String(sequence).padStart(3, '0')}`,
    roomId: 'room_01',
    guestName: `Guest ${sequence}`,
    date: '2026-11-02',
    nights: 1,
    status: 'confirmed',
    ...overrides,
  };
}

export function buildBookings(count: number, overrides: Partial<Booking> = {}): Booking[] {
  return Array.from({ length: count }, () => buildBooking(overrides));
}
