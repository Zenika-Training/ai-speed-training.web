import type { Room } from '../../src/store/types';

let sequence = 0;

export function buildRoom(overrides: Partial<Room> = {}): Room {
  sequence += 1;
  return {
    id: `room_t${String(sequence).padStart(3, '0')}`,
    name: `Test room ${sequence}`,
    capacity: 4,
    floor: 0,
    ...overrides,
  };
}

export function buildRooms(count: number, overrides: Partial<Room> = {}): Room[] {
  return Array.from({ length: count }, () => buildRoom(overrides));
}
