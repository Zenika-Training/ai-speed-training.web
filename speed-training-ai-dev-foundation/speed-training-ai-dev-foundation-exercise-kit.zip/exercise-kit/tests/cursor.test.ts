import { describe, expect, it } from 'vitest';
import {
  DEFAULT_LIMIT,
  InvalidPageRequestError,
  decodeCursor,
  encodeCursor,
  paginate,
  parsePageRequest,
} from '../src/shared/pagination/cursor';

describe('cursor encoding', () => {
  it('round-trips a sort key', () => {
    const key = ['2026-11-02', 'bk_001'];

    expect(decodeCursor(encodeCursor(key))).toEqual(key);
  });

  it('produces an opaque base64url string', () => {
    expect(encodeCursor(['room_01'])).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('rejects a cursor that is not one of ours', () => {
    expect(() => decodeCursor('not-a-cursor')).toThrow(InvalidPageRequestError);
    expect(() => decodeCursor(Buffer.from('{"id":1}').toString('base64url'))).toThrow(InvalidPageRequestError);
  });
});

describe('parsePageRequest', () => {
  it('uses the default limit', () => {
    expect(parsePageRequest({})).toEqual({ limit: DEFAULT_LIMIT, cursor: undefined });
  });

  it.each(['0', '-1', '1.5', '101', 'ten'])('rejects limit=%s', (limit) => {
    expect(() => parsePageRequest({ limit })).toThrow(InvalidPageRequestError);
  });
});

describe('paginate', () => {
  const items = ['a', 'b', 'c', 'd', 'e'].map((id) => ({ id }));
  const byId = (item: { id: string }) => [item.id];

  it('returns the first page and a cursor', () => {
    const page = paginate(items, { limit: 2 }, byId);

    expect(page.items.map((i) => i.id)).toEqual(['a', 'b']);
    expect(page.nextCursor).toBe(encodeCursor(['b']));
  });

  it('starts strictly after the cursor', () => {
    const page = paginate(items, { limit: 2, cursor: encodeCursor(['b']) }, byId);

    expect(page.items.map((i) => i.id)).toEqual(['c', 'd']);
  });

  it('returns nextCursor null on the last page', () => {
    const page = paginate(items, { limit: 2, cursor: encodeCursor(['d']) }, byId);

    expect(page.items.map((i) => i.id)).toEqual(['e']);
    expect(page.nextCursor).toBeNull();
  });

  it('returns an empty page for an empty list', () => {
    expect(paginate([], { limit: 2 }, byId)).toEqual({ items: [], nextCursor: null });
  });
});
