# Booking API — kit d'exercice

Une petite API de réservation de salles, en TypeScript. C'est le terrain des trois exercices de la formation **Développeur IA — Foundation** : tu y ajoutes une fonctionnalité, avec ses tests, dans un code que tu ne connais pas.

Le kit fonctionne avec **n'importe quel agent de code** (Copilot, Claude Code, Codex, Cursor…) : il ne contient aucune configuration propre à un outil.

## Les exercices

Les consignes sont sur les slides et dans le handout « Les exercices ». Les trois sont **optionnels et indépendants** : chacun part du kit tel quel.

1. **Du ticket au plan** (15 min) : sans rien modifier, ton agent propose la demande initiale et un plan pour `TICKET.md` ; tu les corriges.
2. **Petits pas, tests, revue** (20 min) : ton agent implémente une étape du plan avec ses tests (pas de plan ? `docs/plan-de-secours.md`) ; tu relis le diff.
3. **Ma première skill** (10 min) : tu écris en `SKILL.md` une consigne que tu répètes, et tu la testes en session vierge.

## Prérequis

- Node.js 20 ou plus récent (`node --version`)
- Un agent de code, celui que tu utilises d'habitude
- git (facultatif), pour committer et revenir en arrière

## Installation

```bash
npm install
npm test          # toute la suite, quelques secondes
npm run dev       # API sur http://localhost:3000
```

Puis initialise un dépôt git, pour pouvoir committer et revenir en arrière :

```bash
git init
git add -A
git commit -m "Kit d'exercice"
```

Pour vérifier que l'API répond :

```bash
curl "http://localhost:3000/rooms?limit=5"
curl http://localhost:3000/bookings
```

## Commandes

| Commande | Rôle |
|---|---|
| `npm run dev` | lance l'API en mode watch (port 3000, ou `PORT`) |
| `npm test` | lance tous les tests (Vitest) |
| `npm test -- <filtre>` | lance les fichiers de test dont le nom contient le filtre, par exemple `npm test -- rooms` |
| `npm run lint` | vérifie les types (`tsc --noEmit`) |

## Structure

```text
.
├── TICKET.md                    le ticket de l'exercice
├── openapi.yaml                 le contrat de l’API (OpenAPI 3)
├── data/seed.json               les données chargées au démarrage
├── src/
│   ├── app.ts                   l'application Express et ses routes
│   ├── server.ts                le point d'entrée
│   ├── rooms/                   GET /rooms, GET /rooms/:id
│   ├── bookings/                GET /bookings
│   ├── store/                   le store en mémoire et les types
│   └── shared/
│       ├── pagination/          la pagination par curseur
│       └── errors/              les erreurs problem+json
├── tests/
│   ├── factories/               les données de test
│   └── *.test.ts                les tests
└── docs/                        plan de secours (exercices)
```

Les données vivent en mémoire : chaque redémarrage repart de `data/seed.json`.
