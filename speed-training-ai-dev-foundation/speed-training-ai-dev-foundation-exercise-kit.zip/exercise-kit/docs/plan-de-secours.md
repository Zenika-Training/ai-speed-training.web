# Plan de secours — BOOK-142

> **Pas de plan à toi ? Pars de celui-ci.**
> Ce fichier sert à démarrer l'exercice 2 de la formation Foundation sans avoir fini l'exercice 1. Il donne une demande initiale corrigée et un plan en étapes vérifiables. Donne-les à ton agent tels quels, ou corrige-les d'abord.

## Demande initiale

Ajoute une pagination par curseur à `GET /bookings`.

- **Fichiers clés** : `src/bookings/bookings.controller.ts`, `src/shared/pagination/cursor.ts` (le helper à réutiliser), `src/rooms/rooms.controller.ts` (l'exemple d'endpoint déjà paginé), `openapi.yaml`, `tests/factories/`.
- **Commandes** : `npm test -- bookings` pour la boucle courte, `npm test` et `npm run lint` avant de conclure.
- **Réponse attendue** : `{ items, nextCursor }`, comme `GET /rooms` ; paramètres `limit` (1 à 100, 20 par défaut) et `cursor`. `nextCursor` vaut `null` sur la dernière page.
- **Invariants** :
  - le schéma `Page`, les autres endpoints et le format d'erreur (problem+json) ne changent pas ;
  - le curseur reste opaque, au format du helper : pas de nouveau helper, pas de pagination par offset ;
  - le tri actuel (date, puis id) et le filtre `roomId` sont conservés ;
  - un paramètre invalide (`limit`, `cursor`) renvoie une erreur 400 problem+json.
- **Pièges** :
  - plusieurs réservations tombent le même jour : la clé du curseur doit départager les égalités, sinon des réservations sont sautées ou répétées d'une page à l'autre ;
  - aucun test ne couvre aujourd'hui `GET /bookings` : figer le comportement actuel avant de le modifier ;
  - la forme de la réponse change (tableau → page) : c'est le but du ticket, le contrat le documente.
- **Tests** : dans `tests/bookings.test.ts`, données construites avec `tests/factories`, store en mémoire réel, pas de mock.
- **Fini quand** : `npm test` et `npm run lint` passent, et `openapi.yaml` décrit la nouvelle réponse.

Ne modifie rien avant que j'aie validé le plan.

## Plan en étapes vérifiables

Un commit par étape, après relecture.

1. **Figer le comportement actuel.** Écrire `tests/bookings.test.ts` sur le comportement d'aujourd'hui : tri par date puis id (avec deux réservations le même jour), champs renvoyés, filtre `roomId`, liste vide.
   *Vérification* : `npm test -- bookings` passe **sans toucher au code**.
2. **Passer la réponse en page.** Dans `bookings.controller.ts`, lire `limit` et `cursor` avec `parsePageRequest`, paginer avec `paginate` et une clé `[date, id]`, après le filtre `roomId`. Adapter les tests de l'étape 1 à la forme `{ items, nextCursor }` sans changer ce qu'ils vérifient.
   *Vérification* : `npm test -- bookings` passe.
3. **Couvrir la pagination.** Ajouter les tests : parcourir toutes les pages avec `nextCursor` retrouve chaque réservation une seule fois et dans l'ordre, y compris quand plusieurs partagent la même date ; `nextCursor` vaut `null` sur la dernière page ; la pagination respecte le filtre `roomId` ; `limit` ou `cursor` invalide renvoie une 400 problem+json.
   *Vérification* : `npm test -- bookings` passe ; un test échoue si la clé du curseur ne contient que la date.
4. **Mettre le contrat à jour.** Dans `openapi.yaml`, décrire la réponse 200 de `/bookings` comme `/rooms` (`Page` + `items` de `Booking`), ajouter les paramètres `Limit` et `Cursor` et la réponse 400. Le schéma `Page`, `/rooms` et `Problem` restent identiques.
   *Vérification* : relecture du diff de `openapi.yaml` : seule la section `/bookings` change.
5. **Conclure.** Lancer toute la suite et le lint, puis relire le diff complet avec la grille « Relire le code généré ».
   *Vérification* : `npm test` et `npm run lint` passent ; `curl "http://localhost:3000/bookings?limit=5"` renvoie 5 réservations et un `nextCursor`.
