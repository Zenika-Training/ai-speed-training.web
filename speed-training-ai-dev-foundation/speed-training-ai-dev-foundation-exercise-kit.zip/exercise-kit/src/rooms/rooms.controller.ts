import { Router } from 'express';
import type { Store } from '../store/store';
import type { Room } from '../store/types';
import { paginate, parsePageRequest } from '../shared/pagination/cursor';
import { sendProblem } from '../shared/errors/problem';

const roomSortKey = (room: Room) => [room.id];

export function roomsController(store: Store): Router {
  const router = Router();

  // GET /rooms?limit=&cursor= — rooms sorted by id, one page at a time.
  router.get('/', (req, res) => {
    const request = parsePageRequest(req.query);
    const rooms = store.listRooms().sort((a, b) => a.id.localeCompare(b.id));
    res.json(paginate(rooms, request, roomSortKey));
  });

  // GET /rooms/:id
  router.get('/:id', (req, res) => {
    const room = store.findRoom(req.params.id);
    if (!room) {
      sendProblem(res, 404, 'Not Found', `Room ${req.params.id} does not exist`);
      return;
    }
    res.json(room);
  });

  return router;
}
