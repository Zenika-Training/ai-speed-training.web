import type { ErrorRequestHandler, RequestHandler, Response } from 'express';
import { InvalidPageRequestError } from '../pagination/cursor';

/**
 * Every API error is an RFC 9457 problem+json document.
 * See the `Problem` schema in openapi.yaml.
 */
export interface Problem {
  type: string;
  title: string;
  status: number;
  detail?: string;
}

export function sendProblem(res: Response, status: number, title: string, detail?: string): void {
  const problem: Problem = { type: 'about:blank', title, status, ...(detail ? { detail } : {}) };
  res.status(status).type('application/problem+json').send(JSON.stringify(problem));
}

export const notFoundHandler: RequestHandler = (req, res) => {
  sendProblem(res, 404, 'Not Found', `No route for ${req.method} ${req.path}`);
};

export const errorHandler: ErrorRequestHandler = (err, _req, res, _next) => {
  if (err instanceof InvalidPageRequestError) {
    sendProblem(res, 400, 'Bad Request', err.message);
    return;
  }
  console.error(err);
  sendProblem(res, 500, 'Internal Server Error');
};
