/**
 * Cursor pagination shared by every list endpoint.
 *
 * A cursor is opaque for clients: the base64url encoding of the sort key of
 * the last item of the previous page. Clients send it back as `?cursor=`;
 * they must never build or parse it.
 */

export type SortKey = ReadonlyArray<string | number>;

export interface Page<T> {
  items: T[];
  /** Cursor of the next page, or null on the last page. */
  nextCursor: string | null;
}

export interface PageRequest {
  limit: number;
  cursor?: string;
}

export const DEFAULT_LIMIT = 20;
export const MAX_LIMIT = 100;

export class InvalidPageRequestError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'InvalidPageRequestError';
  }
}

export function encodeCursor(key: SortKey): string {
  return Buffer.from(JSON.stringify(key), 'utf8').toString('base64url');
}

export function decodeCursor(cursor: string): SortKey {
  let key: unknown;
  try {
    key = JSON.parse(Buffer.from(cursor, 'base64url').toString('utf8'));
  } catch {
    throw new InvalidPageRequestError('cursor is not a valid cursor');
  }
  const isValid =
    Array.isArray(key) &&
    key.length > 0 &&
    key.every((part) => typeof part === 'string' || typeof part === 'number');
  if (!isValid) {
    throw new InvalidPageRequestError('cursor is not a valid cursor');
  }
  return key as SortKey;
}

/** Reads `limit` and `cursor` from a query string. */
export function parsePageRequest(query: { limit?: unknown; cursor?: unknown }): PageRequest {
  let limit = DEFAULT_LIMIT;
  if (query.limit !== undefined) {
    limit = Number(query.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LIMIT) {
      throw new InvalidPageRequestError(`limit must be an integer between 1 and ${MAX_LIMIT}`);
    }
  }
  if (query.cursor !== undefined && typeof query.cursor !== 'string') {
    throw new InvalidPageRequestError('cursor must be a string');
  }
  return { limit, cursor: query.cursor || undefined };
}

export function compareKeys(a: SortKey, b: SortKey): number {
  const length = Math.min(a.length, b.length);
  for (let i = 0; i < length; i++) {
    if (a[i] < b[i]) return -1;
    if (a[i] > b[i]) return 1;
  }
  return a.length - b.length;
}

/**
 * Returns one page of `items`.
 *
 * `items` must already be sorted by `sortKey`, and `sortKey` must be unique
 * per item: the page starts strictly after the item whose key is the cursor.
 */
export function paginate<T>(
  items: readonly T[],
  request: PageRequest,
  sortKey: (item: T) => SortKey,
): Page<T> {
  let start = 0;
  if (request.cursor) {
    const after = decodeCursor(request.cursor);
    start = items.findIndex((item) => compareKeys(sortKey(item), after) > 0);
    if (start === -1) start = items.length;
  }
  const pageItems = items.slice(start, start + request.limit);
  const hasMore = start + request.limit < items.length;
  const last = pageItems[pageItems.length - 1];
  return {
    items: pageItems,
    nextCursor: hasMore && last !== undefined ? encodeCursor(sortKey(last)) : null,
  };
}
