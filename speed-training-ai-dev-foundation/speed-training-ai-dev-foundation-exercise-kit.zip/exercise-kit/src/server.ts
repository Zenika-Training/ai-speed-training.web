import { createApp } from './app';
import { createStore } from './store/store';

const port = Number(process.env.PORT ?? 3000);

createApp(createStore()).listen(port, () => {
  console.log(`Booking API on http://localhost:${port}`);
});
