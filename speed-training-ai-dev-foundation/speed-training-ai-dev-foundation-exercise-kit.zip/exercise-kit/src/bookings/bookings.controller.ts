import { Router } from 'express';
import type { Store } from '../store/store';

export function bookingsController(store: Store): Router {
  const router = Router();

  // GET /bookings?roomId= — every booking, by date then id.
  router.get('/', (req, res) => {
    const { roomId } = req.query;
    const bookings = store
      .listBookings()
      .sort((a, b) => a.date.localeCompare(b.date) || a.id.localeCompare(b.id));
    const result = typeof roomId === 'string' ? bookings.filter((b) => b.roomId === roomId) : bookings;
    res.json(result);
  });

  return router;
}
