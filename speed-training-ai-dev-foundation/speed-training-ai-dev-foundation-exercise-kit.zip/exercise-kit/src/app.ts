import express from 'express';
import type { Store } from './store/store';
import { roomsController } from './rooms/rooms.controller';
import { bookingsController } from './bookings/bookings.controller';
import { errorHandler, notFoundHandler } from './shared/errors/problem';

export function createApp(store: Store) {
  const app = express();
  app.use(express.json());

  app.use('/rooms', roomsController(store));
  app.use('/bookings', bookingsController(store));

  app.use(notFoundHandler);
  app.use(errorHandler);
  return app;
}
