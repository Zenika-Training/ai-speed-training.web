import { readFileSync } from 'node:fs';
import type { Booking, Room, Seed } from './types';

/**
 * In-memory store. The API reads and writes through it; tests build their own
 * store with tests/factories instead of mocking it.
 */
export class Store {
  private readonly rooms: Room[];
  private readonly bookings: Booking[];

  constructor(seed: Seed = { rooms: [], bookings: [] }) {
    this.rooms = [...seed.rooms];
    this.bookings = [...seed.bookings];
  }

  listRooms(): Room[] {
    return [...this.rooms];
  }

  findRoom(id: string): Room | undefined {
    return this.rooms.find((room) => room.id === id);
  }

  addRoom(room: Room): Room {
    this.rooms.push(room);
    return room;
  }

  listBookings(): Booking[] {
    return this.bookings;
  }

  addBooking(booking: Booking): Booking {
    this.bookings.push(booking);
    return booking;
  }
}

export function loadSeed(): Seed {
  const url = new URL('../../data/seed.json', import.meta.url);
  return JSON.parse(readFileSync(url, 'utf8')) as Seed;
}

export function createStore(seed: Seed = loadSeed()): Store {
  return new Store(seed);
}
