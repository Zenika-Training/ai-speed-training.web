export interface Room {
  id: string;
  name: string;
  capacity: number;
  floor: number;
}

export type BookingStatus = 'confirmed' | 'pending' | 'cancelled';

export interface Booking {
  id: string;
  roomId: string;
  guestName: string;
  /** Day of arrival, ISO format YYYY-MM-DD. */
  date: string;
  nights: number;
  status: BookingStatus;
}

export interface Seed {
  rooms: Room[];
  bookings: Booking[];
}
