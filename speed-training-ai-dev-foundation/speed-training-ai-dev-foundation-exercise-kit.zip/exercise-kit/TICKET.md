# BOOK-142

Pagine /bookings, la liste est trop longue côté mobile.
