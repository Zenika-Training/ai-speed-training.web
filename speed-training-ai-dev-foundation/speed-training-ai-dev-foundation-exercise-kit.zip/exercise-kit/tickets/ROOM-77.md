# ROOM-77

Filtrer GET /rooms par capacité minimale : `?minCapacity=10` ne renvoie que les salles d'au moins 10 places. La pagination existante ne change pas.
