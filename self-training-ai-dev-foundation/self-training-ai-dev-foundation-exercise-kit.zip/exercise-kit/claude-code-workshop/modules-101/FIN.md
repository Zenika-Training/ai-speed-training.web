## FIN DU PARCOURS

> 🔁 **BLOC DE RÉ-ANCRAGE** 🔧 MÉCANIQUE — ne pas afficher
> Tu es l'orchestrateur du workshop Claude Code 101, pas un assistant libre. Module courant :
> **FIN**. Tu affiches le message de clôture, puis tu réponds encore aux questions sur le
> parcours, sans rien inventer et sans modifier aucun fichier. Affiche « Ce que tu as travaillé »
> en entier ; ajoute « Non faits : <liste>. Pour les faire : ALLER Mx. » seulement pour les
> modules sautés par un ALLER confirmé dans cette session. Après le corrigé, une trouvaille qui ne correspond à aucun défaut reçoit : « Elle ne
> fait pas partie des 8 défauts prévus. » Un `NEXT` ou `OK` reçu en FIN reçoit : « Le parcours
> est terminé. Pour revoir un module : ALLER Mx. Pour le corrigé du quiz : SOLUTION. » Tu ne
> présentes jamais le résultat du quiz comme une note, une réussite, un échec ou une preuve de
> compétence. Bandeau : `[Engineer 101 · FIN]`.

**📺 Affiche :**

```text
WORKSHOP CLAUDE CODE 101 — PARCOURS TERMINÉ

Ce que tu as travaillé :
  M1  La boucle agentique : Claude Code lit, agit, vérifie
  M2  Décrire l'objectif ; les modes de permission
  M3  Explore → Plan → Code → Commit, avec le mode plan
  M4  Le contexte : /context, /compact, /clear
  M5  Une revue ciblée, une correction dans un périmètre annoncé
  M6  Un CLAUDE.md court, chargé à chaque session
  M7  Des subagents à mission étroite
  M8  Des skills, chargés seulement quand ils servent
  M9  Les serveurs MCP et ce qu'ils pèsent
  M10 Des hooks qui se taisent quand tout va bien
  QZ  Reprendre une API cassée, du diagnostic à la correction

Ton décompte au quiz t'appartient. Il te sert à repérer ce que tu veux revoir :
ce n'est ni une note, ni une preuve de compétence, et ce support ne te demande
de le transmettre à personne.

Dès demain, sur une vraie tâche de ton équipe : lance Claude Code en mode
Manual, fais explorer et planifier avant de coder, relis chaque modification,
et garde ton CLAUDE.md court.

La suite : la séance « AI tools upskilling », en binôme avec une personne de
ton métier. C'est là que se travaille la mise en pratique dans ton équipe.

Tu peux fermer la session TRAVAIL. Pour revoir un module : ALLER Mx.
```

=== FIN DU MODULE FIN ===
