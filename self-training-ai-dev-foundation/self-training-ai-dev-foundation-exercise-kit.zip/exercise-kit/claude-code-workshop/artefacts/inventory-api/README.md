# Inventory API

API REST de gestion de stock. Version 0.9.0, reprise d'une équipe précédente.

## Prérequis

- Java 21+
- Maven 3.9+

## Démarrage et tests

    mvn spring-boot:run
    mvn test

`.mvn/maven.config` active le mode silencieux de Maven : un succès n'affiche presque rien, un
échec affiche le test en cause. La sortie des tests est rangée dans `target/surefire-reports/`.

## Contrat de l'API

Un article (`Item`) a les champs suivants.

| Champ | Règle |
|---|---|
| `id` | attribué par l'API, à partir de 1 |
| `name` | obligatoire, non vide |
| `quantity` | entier, jamais négatif |
| `price` | jamais négatif |
| `category` | facultative |

| Méthode et chemin | Réponse attendue |
|---|---|
| `GET /items` | 200, liste des articles |
| `GET /items?category=electronics` | 200, articles de la catégorie ; un article sans catégorie n'apparaît simplement pas |
| `GET /items/{id}` | 200 avec l'article, 404 s'il n'existe pas |
| `GET /items/low-stock` | 200, articles dont la quantité est strictement inférieure à 5 |
| `POST /items` | 201 avec l'article créé ; 400 si un champ ne respecte pas sa règle |
| `PUT /items/{id}` | 200 avec l'article modifié ; 404 s'il n'existe pas ; 400 si un champ ne respecte pas sa règle |
| `POST /items/{id}/restock?quantity=N` | 200 ; ajoute N unités au stock existant ; 400 si N est inférieur à 1 ; 404 si l'article n'existe pas |
| `DELETE /items/{id}` | 200 si l'article est supprimé, 404 s'il n'existe pas |

## Données de démonstration

Chargées au démarrage, en mémoire :

| id | name | quantity | price | category |
|---|---|---|---|---|
| 1 | Laptop | 10 | 999.99 | electronics |
| 2 | Mouse | 50 | 29.99 | electronics |
| 3 | Desk | 5 | 299.99 | furniture |

## Exemples

    curl http://localhost:8080/items/1
    curl -X POST http://localhost:8080/items \
      -H "Content-Type: application/json" \
      -d '{"name":"Keyboard","quantity":20,"price":49.90,"category":"electronics"}'
    curl -X POST "http://localhost:8080/items/2/restock?quantity=10"
