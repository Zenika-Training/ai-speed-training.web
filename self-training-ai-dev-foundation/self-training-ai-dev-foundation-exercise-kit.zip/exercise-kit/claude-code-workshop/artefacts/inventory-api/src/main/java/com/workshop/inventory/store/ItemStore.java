package com.workshop.inventory.store;

import com.workshop.inventory.model.Item;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

@Component
public class ItemStore {

    private final Map<Long, Item> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(0);

    public ItemStore() {
        save(new Item(null, "Laptop", 10, 999.99, "electronics"));
        save(new Item(null, "Mouse", 50, 29.99, "electronics"));
        save(new Item(null, "Desk", 5, 299.99, "furniture"));
    }

    public List<Item> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Item> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public List<Item> findByCategory(String category) {
        return store.values().stream()
                .filter(i -> i.getCategory().equals(category))
                .toList();
    }

    public Item save(Item item) {
        if (item.getId() == null) {
            item.setId(sequence.getAndIncrement());
        }
        store.put(item.getId(), item);
        return item;
    }

    public boolean deleteById(Long id) {
        return store.remove(id) != null;
    }

    public Optional<Item> restock(Long id, int quantity) {
        Item item = store.get(id);
        if (item == null) {
            return Optional.empty();
        }
        item.setQuantity(quantity);
        return Optional.of(item);
    }
}
