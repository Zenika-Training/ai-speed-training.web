package com.workshop.inventory.controller;

import com.workshop.inventory.model.Item;
import com.workshop.inventory.store.ItemStore;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/items")
public class ItemController {

    private final ItemStore itemStore;

    public ItemController(ItemStore itemStore) {
        this.itemStore = itemStore;
    }

    @GetMapping
    public List<Item> getAllItems(@RequestParam(required = false) String category) {
        if (category != null) {
            return itemStore.findByCategory(category);
        }
        return itemStore.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Item> getItemById(@PathVariable Long id) {
        return itemStore.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/low-stock")
    public List<Item> getLowStockItems() {
        return itemStore.findAll().stream()
                .filter(i -> i.getQuantity() < 5)
                .toList();
    }

    @PostMapping
    public ResponseEntity<Item> createItem(@RequestBody Item item) {
        Item created = itemStore.save(item);
        return ResponseEntity.ok(created);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Item> updateItem(@PathVariable Long id,
                                           @Valid @RequestBody Item item) {
        if (itemStore.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        item.setId(id);
        return ResponseEntity.ok(itemStore.save(item));
    }

    @PostMapping("/{id}/restock")
    public ResponseEntity<Item> restockItem(@PathVariable Long id,
                                            @RequestParam int quantity) {
        if (quantity < 1) {
            return ResponseEntity.badRequest().build();
        }
        return itemStore.restock(id, quantity)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteItem(@PathVariable Long id) {
        itemStore.deleteById(id);
        return ResponseEntity.ok().build();
    }
}
