# Tasks API - Spring Boot

API REST de gestion de tâches - workshop Claude Code 101.

## Prérequis

- Java 21+
- Maven 3.9+

## Démarrage

    mvn spring-boot:run

## Endpoints

- GET    /tasks        - Lister toutes les tâches
- GET    /tasks/{id}   - Récupérer une tâche
- POST   /tasks        - Créer une tâche
- PUT    /tasks/{id}   - Modifier une tâche
- DELETE /tasks/{id}   - Supprimer une tâche

## Tests

    mvn test

## Sortie de Maven

Le projet est réglé pour une sortie courte : `.mvn/maven.config` active le mode silencieux
(`-q`) et la sortie des tests est rangée dans `target/surefire-reports/`. Un succès n'affiche
presque rien ; un échec affiche le test en cause et son message.

## Tester manuellement

    curl http://localhost:8080/tasks

    curl -X POST http://localhost:8080/tasks \
      -H "Content-Type: application/json" \
      -d '{"title":"Ma tâche","description":"Détails","priority":2}'

## Notes

- Données en mémoire : réinitialisées au redémarrage
- Validation via Bean Validation (@NotBlank, @Min, @Max)
