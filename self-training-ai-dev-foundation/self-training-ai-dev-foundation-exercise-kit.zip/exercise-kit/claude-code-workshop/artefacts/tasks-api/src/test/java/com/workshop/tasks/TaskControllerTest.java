package com.workshop.tasks;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.workshop.tasks.model.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class TaskControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void getAllTasks_returnsOk() throws Exception {
        mockMvc.perform(get("/tasks"))
               .andExpect(status().isOk())
               .andExpect(content().contentType(MediaType.APPLICATION_JSON));
    }

    @Test
    void createTask_returnsCreated() throws Exception {
        Task task = new Task(null, "Test task", "Description", 2);
        mockMvc.perform(post("/tasks")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(task)))
               .andExpect(status().isCreated())
               .andExpect(jsonPath("$.title").value("Test task"));
    }

    @Test
    void createTask_withoutTitle_returnsBadRequest() throws Exception {
        Task task = new Task(null, "", "Description", 2);
        mockMvc.perform(post("/tasks")
               .contentType(MediaType.APPLICATION_JSON)
               .content(objectMapper.writeValueAsString(task)))
               .andExpect(status().isBadRequest());
    }

    @Test
    void getTask_notFound_returns404() throws Exception {
        mockMvc.perform(get("/tasks/9999"))
               .andExpect(status().isNotFound());
    }
}
