package com.workshop.tasks.store;

import com.workshop.tasks.model.Task;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Store en mémoire - remplace une base de données pour ce workshop.
 * Les données sont réinitialisées à chaque redémarrage.
 */
@Component
public class TaskStore {

    private final Map<Long, Task> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    public TaskStore() {
        // Données de démo
        save(new Task(null, "Lire la doc Spring Boot", "Lire spring.io/guides", 2));
        save(new Task(null, "Écrire des tests", "Couvrir les endpoints principaux", 1));
        save(new Task(null, "Déployer l'API", "Déployer sur un serveur", 3));
    }

    public List<Task> findAll() {
        return new ArrayList<>(store.values());
    }

    public Optional<Task> findById(Long id) {
        return Optional.ofNullable(store.get(id));
    }

    public Task save(Task task) {
        if (task.getId() == null) {
            task.setId(sequence.getAndIncrement());
        }
        store.put(task.getId(), task);
        return task;
    }

    public boolean deleteById(Long id) {
        return store.remove(id) != null;
    }

    public boolean existsById(Long id) {
        return store.containsKey(id);
    }
}
