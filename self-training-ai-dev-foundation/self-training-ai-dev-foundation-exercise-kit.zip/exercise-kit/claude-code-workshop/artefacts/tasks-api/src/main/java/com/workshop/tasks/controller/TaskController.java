package com.workshop.tasks.controller;

import com.workshop.tasks.model.Task;
import com.workshop.tasks.store.TaskStore;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private final TaskStore taskStore;

    public TaskController(TaskStore taskStore) {
        this.taskStore = taskStore;
    }

    /** Liste toutes les tâches */
    @GetMapping
    public List<Task> getAllTasks() {
        return taskStore.findAll();
    }

    /** Récupère une tâche par son ID */
    @GetMapping("/{id}")
    public ResponseEntity<Task> getTaskById(@PathVariable Long id) {
        return taskStore.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /** Crée une nouvelle tâche */
    @PostMapping
    public ResponseEntity<Task> createTask(@Valid @RequestBody Task task) {
        Task created = taskStore.save(task);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    /** Met à jour une tâche existante */
    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(@PathVariable Long id,
                                           @Valid @RequestBody Task task) {
        if (!taskStore.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        task.setId(id);
        return ResponseEntity.ok(taskStore.save(task));
    }

    /** Supprime une tâche */
    @DeleteMapping("/{id}")
    public ResponseEntity<Map<String, String>> deleteTask(@PathVariable Long id) {
        if (!taskStore.deleteById(id)) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(Map.of("message", "Task deleted"));
    }
}
