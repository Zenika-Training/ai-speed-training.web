#!/usr/bin/env bash
# Prépare le conteneur du workshop : droits sur la configuration de Claude Code (volume persistant),
# puis téléchargement des dépendances Maven de chaque projet d'exercice, pour que le premier
# mvn -q test du parcours soit immédiat.
set -uo pipefail

sudo chown -R "$(id -u):$(id -g)" "$HOME/.claude" 2>/dev/null || true

for projet in artefacts/*/; do
  [ -f "${projet}pom.xml" ] || continue
  echo "Dépendances Maven : ${projet}"
  if ! (cd "$projet" && mvn -q -B -Dmaven.test.failure.ignore=true test > /dev/null 2>&1); then
    echo "  Échec du téléchargement : vérifie l'accès au dépôt Maven, puis lance mvn -q test dans ${projet}"
  fi
  rm -rf "${projet}target"
done

echo "Conteneur prêt : java, mvn, git et claude sont installés."
