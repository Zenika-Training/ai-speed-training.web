# Commencer ici — workshop Claude Code 101

Ce dossier contient tout ce qu'il faut pour suivre le workshop : le cours et deux projets
d'exercice. Durée : environ 4 h, quiz final compris. Tu peux t'arrêter à la fin d'un module et
reprendre plus tard.

Tu vas utiliser **deux sessions Claude Code, dans deux terminaux** :

- **SUPPORT** te guide pas à pas, ne modifie aucun fichier, et devient ton coach au quiz final ;
- **TRAVAIL** est la session où tu fais les exercices, dans un projet, comme au quotidien.

## 1. Vérifie ton poste

Il te faut Claude Code avec ton accès ouvert, Java 21 ou plus, Maven 3.9 ou plus, git, et un
terminal bash ou zsh (sous Windows, Git Bash). Vérifie dans un terminal :

```sh
claude --version
java -version
mvn -v
git --version
```

Si `java` ou `mvn` ne répondent pas, rends-les disponibles avant de commencer. Si tu gères tes
versions avec un outil comme SDKMAN! ou mise, active Java 21 et Maven 3.9 pour ce dossier.

### Sans rien installer : le devcontainer

Tu as Docker sur ton poste, et VS Code avec l'extension Dev Containers (ou un autre outil
compatible devcontainer) ? Ouvre ce dossier, puis choisis « Reopen in Container ». Le conteneur
installe Java 21, Maven 3.9, git et Claude Code, et télécharge à l'avance les dépendances Maven
des projets : le premier `mvn -q test` du parcours est immédiat.

- Ouvre ensuite tes deux terminaux dans VS Code, comme décrit plus bas : SUPPORT dans ce
  dossier, TRAVAIL dans `artefacts/tasks-api`.
- Au premier lancement de `claude`, connecte-toi : la connexion est gardée d'un redémarrage du
  conteneur à l'autre.
- Si ton poste passe par un dépôt Maven d'entreprise, copie ton `settings.xml` dans `~/.m2/` du
  conteneur, puis relance `bash .devcontainer/post-create.sh`.
- Tes plugins et hooks Claude Code personnels ne sont pas chargés dans le conteneur : le
  parcours s'y joue tel qu'il est écrit.

## 2. Place ce dossier hors de tout projet

Ce dossier ne doit pas se trouver dans un projet qui contient un fichier `CLAUDE.md` : Claude Code
le chargerait aussi, et le parcours se comporterait autrement.

## 3. Lance la session SUPPORT

Ouvre un premier terminal **dans ce dossier** et lance :

```sh
claude --permission-mode default
```

Puis écris :

```
Lis le fichier CLAUDE-CODE-WORKSHOP.md et démarre.
```

L'option `--permission-mode default` fait démarrer Claude Code en mode Manual : il te demande ton
accord avant de modifier un fichier ou de lancer une commande.

## 4. Ouvre la session TRAVAIL quand SUPPORT te le demande

À l'étape 0.3, ouvre un second terminal **dans ce dossier** et tape :

```sh
cd artefacts/tasks-api
git init -q && git add -A && git commit -qm "Etat initial"
mvn -q test
claude --permission-mode default
```

Le premier `mvn -q test` télécharge les dépendances sans rien afficher : compte une à deux
minutes. Si git te demande ton identité, configure-la comme d'habitude. Sous la zone de saisie de
TRAVAIL, tu dois lire `manual mode on`.

Tape ensuite `/model`, dans TRAVAIL puis dans SUPPORT, pour voir le modèle actif. Un modèle
intermédiaire (Sonnet) suffit pour tout le parcours : un modèle plus puissant (Opus) est plus lent
et consomme plus, sans rien apporter à ces exercices. Choisis parmi les modèles que ton entreprise
autorise.

## 5. Le déroulé de chaque exercice

1. SUPPORT affiche un prompt.
2. Tu le colles dans TRAVAIL.
3. Tu observes ce que fait Claude Code, et tu acceptes ou refuses chaque demande d'approbation. Si
   une demande te propose de passer en mode auto, ne choisis pas cette option.
4. Tu reviens dans SUPPORT et tu tapes `NEXT`, ou tu colles ton résultat pour qu'il le commente.

## 6. Deux pauses pour alléger SUPPORT

À la fin du module M4, puis avant le quiz, SUPPORT te propose de taper `/clear` suivi d'une phrase
de reprise. Cela vide la session des modules déjà faits. C'est facultatif : `NEXT` fonctionne
aussi.

## 7. Le quiz final

- SUPPORT te donne les commandes pour ouvrir TRAVAIL dans `artefacts/inventory-api`, une API
  cassée à reprendre.
- Tu y cherches et tu corriges les défauts avec Claude Code.
- Tu écris tes trouvailles dans SUPPORT, une par ligne : où se trouve le défaut, et pourquoi c'est
  un problème. SUPPORT te dit combien tu en as trouvé sur 8, jamais lesquels.
- `INDICE` donne un indice, `SOLUTION` le corrigé commenté, `TERMINÉ` ton décompte final. Ce
  décompte n'est ni une note ni une évaluation : il te dit quoi revoir.

## 8. Reprendre plus tard

Dans ce dossier, relance `claude --permission-mode default`, puis écris, avec le numéro du module
où tu t'étais arrêté :

```
Lis le fichier CLAUDE-CODE-WORKSHOP.md et va au module M4.
```

Si ta session TRAVAIL est fermée, SUPPORT te dit comment la rouvrir.

## Tes commandes dans SUPPORT

| Commande | Effet |
|---|---|
| `NEXT` ou `OK` | Passer à l'étape suivante |
| `RÉPÈTE` | Réafficher l'étape en cours |
| `OÙ EN SUIS-JE` | Voir où tu en es |
| `RECADRE` | Si l'IA s'écarte du parcours, elle reprend son rôle |
| `KO` | Un checkpoint ne passe pas : SUPPORT t'aide à voir pourquoi, sans te bloquer |
| `ALLER M4` | Aller directement à un module, après confirmation |
| `ENGLISH`, `FRANÇAIS` | Changer de langue |
| `INDICE`, `SOLUTION`, `TERMINÉ` | Pendant le quiz final seulement |

## Si quelque chose ne va pas

- **`mvn` ou `java` introuvable** : reprends l'étape 1.
- **TRAVAIL n'affiche pas `manual mode on`** : quitte-la avec `/exit` et relance
  `claude --permission-mode default`.
- **SUPPORT s'écarte du parcours** : écris `RECADRE`.
- **Un checkpoint ne passe pas** : écris `KO` dans SUPPORT.
- **Ta configuration personnelle de Claude Code ajoute des plugins ou des hooks** : ils se chargent
  aussi dans les deux sessions et peuvent perturber le parcours. Pour les écarter le temps du
  workshop, ajoute `--setting-sources project,local` à chaque lancement.
- **Une question sur ton quota, tes accès ou les outils autorisés** : pose-la à ton référent.

## Ce que contient ce dossier

| Élément | Rôle |
|---|---|
| `COMMENCER-ICI.md` | Ce guide |
| `CLAUDE-CODE-WORKSHOP.md` | Le point d'entrée du cours, lu par la session SUPPORT |
| `modules-101/` | Les modules M1 à M9, le quiz et la fin du parcours |
| `artefacts/tasks-api/` | Le projet des exercices |
| `artefacts/inventory-api/` | Le projet du quiz final |

Les fichiers du cours contiennent aussi les instructions données à l'IA et le corrigé du quiz. Tu
peux les lire : rien ne t'en empêche, et rien ne dépend de ton score. Mais le quiz n'entraîne ton
œil que si tu le fais sans regarder.
